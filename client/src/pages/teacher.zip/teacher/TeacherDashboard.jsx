import React, { useMemo } from 'react';
import { useAuth } from '../../contexts/AuthContext.jsx';
import { useStudents } from '../../hooks/useStudents.js';
import { useReports } from '../../hooks/useReports.js';
import DashboardLayout from '../../components/layout/DashboardLayout.jsx';
import DeptTimetableView from '../../components/DeptTimetableView.jsx';
import PersonalTimetable from '../../components/PersonalTimetable.jsx';
import { Users, BarChart2, FileText, Trash2 } from 'lucide-react';
import {
    BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from 'recharts';

/* ── All month columns in chronological order ─────────────────── */
const ALL_MONTH_COLS = [
    { key: 'jan_att', label: 'Jan' }, { key: 'feb_att', label: 'Feb' },
    { key: 'mar_att', label: 'Mar' }, { key: 'apr_att', label: 'Apr' },
    { key: 'may_att', label: 'May' }, { key: 'jun_att', label: 'Jun' },
    { key: 'jul_att', label: 'Jul' }, { key: 'aug_att', label: 'Aug' },
    { key: 'sep_att', label: 'Sep' }, { key: 'oct_att', label: 'Oct' },
    { key: 'nov_att', label: 'Nov' }, { key: 'dec_att', label: 'Dec' },
];

/* ── Year → semester mapping (same as TeacherStudents) ─────────── */
const YEAR_SEM = { 1: [1, 2], 2: [3, 4], 3: [5, 6], 4: [7, 8] };
const YEAR_LABELS = ['1st Year', '2nd Year', '3rd Year', '4th Year'];

/* ── Chart colours per semester ─────────────────────────────────── */
const SEM_COLORS = {
    1: '#1e3a8a', 2: '#7c3aed', 3: '#38bdf8', 4: '#0891b2',
    5: '#16a34a', 6: '#4ade80', 7: '#d97706', 8: '#ea580c',
};

/**
 * Build bar-chart data for one semester.
 * Only includes months where at least one student has data > 0.
 * Average is computed across students that have data for that month.
 */
function getSemChartData(students, year, semester) {
    const semStudents = students.filter(
        s => Number(s.year) === year && Number(s.semester) === semester
    );
    if (!semStudents.length) return [];

    return ALL_MONTH_COLS
        .filter(col => semStudents.some(s => Number(s[col.key]) > 0))
        .map(col => {
            const vals = semStudents.map(s => Number(s[col.key]) || 0).filter(v => v > 0);
            const avg = vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : 0;
            return { month: col.label, attendance: parseFloat(avg.toFixed(1)) };
        });
}

/* ─────────────────────────────────────────────
   Semester Chart Component
───────────────────────────────────────────── */

/* ─────────────────────────────────────────────
   Status Badge Maps
───────────────────────────────────────────── */

const STATUS_BADGE = {
    draft: 'bg-gray-100 text-gray-600',
    submitted_to_hod: 'bg-blue-100 text-blue-700',
    submitted_to_principal: 'bg-purple-100 text-purple-700',
    approved: 'bg-green-100 text-green-700',
};

const STATUS_LABEL = {
    draft: 'Draft',
    submitted_to_hod: 'Submitted To HOD',
    submitted_to_principal: 'Submitted To Principal',
    approved: 'Approved',
};

/* ─────────────────────────────────────────────
   Main Component
───────────────────────────────────────────── */

export default function TeacherDashboard() {
    const { user, departmentId } = useAuth();
    const { students = [], loading: studentsLoading } =
        useStudents(user?.id, departmentId);

    const { reports = [], loading: reportsLoading, deleteReport } =
        useReports(user?.id, 'teacher', departmentId);

    /* Year-wise average attendance — computed from monthly columns (real-time) */
    const yearWiseAvg = useMemo(() => {
        const MONTH_KEYS = ALL_MONTH_COLS.map(c => c.key);
        return [1, 2, 3, 4].map(year => {
            const yearStudents = students.filter(s => Number(s.year) === year);
            if (!yearStudents.length) return { year, avg: 0 };

            // For each student, compute their personal avg from non-zero months
            const studentAvgs = yearStudents
                .map(s => {
                    const vals = MONTH_KEYS
                        .map(k => Number(s[k]))
                        .filter(v => v > 0);
                    return vals.length
                        ? vals.reduce((a, b) => a + b, 0) / vals.length
                        : null;
                })
                .filter(v => v !== null);

            // Then average across all students who have data
            const avg = studentAvgs.length
                ? studentAvgs.reduce((a, b) => a + b, 0) / studentAvgs.length
                : 0;

            return { year, avg: Math.round(avg) };
        });
    }, [students]);

    /* Recent Reports */
    const recentReports = useMemo(() => {
        return [...reports]
            .sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
            .slice(0, 5);
    }, [reports]);

    const fmtDate = (date) => {
        const d = new Date(date);
        return `${d.getDate().toString().padStart(2, '0')}/${(d.getMonth() + 1).toString().padStart(2, '0')
            }/${d.getFullYear()}`;
    };

    return (
        <DashboardLayout>
            <div className="mb-6">
                <h1 className="text-2xl font-bold">Teacher Dashboard</h1>
                <p className="text-sm text-gray-400">
                    Welcome back, {user?.name || 'Teacher'}!
                </p>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-10">
                <StatCard
                    label="Total Students"
                    value={studentsLoading ? '...' : students.length}
                    icon={<Users size={20} />}
                />

                <StatCard
                    label="Reports Generated"
                    value={reportsLoading ? '...' : reports.length}
                    icon={<FileText size={20} />}
                />

                {/* Year-wise Avg Attendance card */}
                <div className="bg-white rounded-xl border p-6 flex flex-col justify-between">
                    <div className="flex items-center justify-between mb-3">
                        <p className="text-sm text-gray-500">Avg. Attendance (Year-wise)</p>
                        <div className="bg-gray-100 p-3 rounded-full"><BarChart2 size={20} /></div>
                    </div>
                    <div className="grid grid-cols-4 gap-2 text-center">
                        {yearWiseAvg.map(({ year, avg }) => (
                            <div key={year}>
                                <p className="text-[11px] text-gray-400 mb-0.5">{['1st', '2nd', '3rd', '4th'][year - 1]} Year</p>
                                <p className="text-xl font-bold text-gray-900">{avg}%</p>
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            {/* Attendance Charts */}
            {[1, 2, 3, 4].map(year => (
                <div key={year} className="mb-10">
                    <h2 className="font-bold mb-4">
                        {YEAR_LABELS[year - 1]} — Monthly Attendance Trend
                    </h2>
                    <div className="grid md:grid-cols-2 gap-4">
                        {(YEAR_SEM[year] || []).map(sem => {
                            const data = getSemChartData(students, year, sem);
                            return (
                                <div key={sem} className="bg-white rounded-xl border border-gray-200 p-4">
                                    <p className="text-sm font-semibold text-gray-500 mb-3">Semester {sem}</p>
                                    {data.length === 0 ? (
                                        <div className="h-[180px] flex items-center justify-center text-gray-300 text-sm">
                                            No attendance data yet
                                        </div>
                                    ) : (
                                        <ResponsiveContainer width="100%" height={180}>
                                            <BarChart data={data}>
                                                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                                                <XAxis dataKey="month" />
                                                <YAxis domain={[0, 100]} />
                                                <Tooltip formatter={val => [`${val}%`, 'Avg Attendance']} />
                                                <Bar dataKey="attendance" fill={SEM_COLORS[sem]} radius={[4, 4, 0, 0]} />
                                            </BarChart>
                                        </ResponsiveContainer>
                                    )}
                                </div>
                            );
                        })}
                    </div>
                </div>
            ))}

            {/* Recent Reports */}
            <div>
                <h2 className="font-bold mb-4">Recent Reports</h2>

                {reportsLoading ? (
                    <p>Loading...</p>
                ) : recentReports.length === 0 ? (
                    <p className="text-gray-400">No reports yet.</p>
                ) : (
                    recentReports.map(report => (
                        <div key={report.id} className="flex justify-between items-center border-b py-3">
                            <div>
                                <p className="font-medium">{report.title}</p>
                                <p className="text-xs text-gray-400">
                                    Created on {fmtDate(report.createdAt)}
                                </p>
                            </div>

                            <div className="flex items-center gap-2">
                                <span
                                    className={`px-3 py-1 rounded text-xs ${STATUS_BADGE[report.status] || STATUS_BADGE.draft
                                        }`}
                                >
                                    {STATUS_LABEL[report.status] || report.status}
                                </span>
                                {report.status === 'draft' && (
                                    <button
                                        onClick={() => deleteReport(report.id)}
                                        className="text-gray-400 hover:text-red-500 transition-colors p-1 rounded"
                                        title="Delete draft"
                                    >
                                        <Trash2 className="w-4 h-4" />
                                    </button>
                                )}
                            </div>
                        </div>
                    ))
                )}
            </div>

            {/* My Personal Timetable */}
            <div className="mt-6">
                <h2 className="font-bold mb-4">My Personal Timetable</h2>
                <PersonalTimetable
                    userId={user?.id}
                    departmentId={departmentId}
                />
            </div>

            {/* Department Timetable */}
            <div className="mt-6">
                <h2 className="font-bold mb-4">Department Timetable</h2>
                <DeptTimetableView
                    departmentId={departmentId}
                    departmentName={user?.department}
                    userId={user?.id}
                />
            </div>
        </DashboardLayout>
    );
}

/* Small reusable stat card */
function StatCard({ label, value, icon }) {
    return (
        <div className="bg-white rounded-xl border p-6 flex justify-between items-center">
            <div>
                <p className="text-sm text-gray-500">{label}</p>
                <p className="text-3xl font-bold">{value}</p>
            </div>
            <div className="bg-gray-100 p-3 rounded-full">{icon}</div>
        </div>
    );
}