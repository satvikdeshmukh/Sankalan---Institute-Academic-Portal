import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../../contexts/AuthContext.jsx';
import { useProfile } from '../../hooks/useProfile.js';
import { useDocuments } from '../../hooks/useDocuments.js';
import DashboardLayout from '../../components/layout/DashboardLayout.jsx';
import { Save, Upload, Download, Trash2, FileText, Loader2 } from 'lucide-react';

function formatSize(bytes) {
    if (!bytes) return '—';
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return Math.round(bytes / 1024) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
}

function fmtDate(d) {
    const dt = new Date(d);
    return `${String(dt.getDate()).padStart(2, '0')}/${String(dt.getMonth() + 1).padStart(2, '0')}/${dt.getFullYear()}`;
}

const inputCls = "w-full px-3 py-2.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white placeholder-gray-400";

export default function TeacherProfile() {
    const { user, departmentId } = useAuth();
    const { profile, loading: pLoading, updateProfile } = useProfile(user?.id);
    const { documents, loading: dLoading, uploadDocument, deleteDocument } = useDocuments(user?.id);

    const [form, setForm] = useState({ name: '', email: '', phone: '', qualifications: '', experience: '', bio: '' });
    const [saving, setSaving] = useState(false);
    const [saveMsg, setSaveMsg] = useState('');
    const [uploading, setUploading] = useState(false);

    const fileRef = useRef();

    // Populate form when profile loads
    useEffect(() => {
        if (profile) {
            setForm({
                name: profile.full_name || user?.name || '',
                email: user?.email || '',
                phone: profile.phone || '',
                qualifications: profile.qualifications || '',
                experience: profile.experience || '',
                bio: profile.bio || '',
            });
        } else if (user) {
            setForm(f => ({ ...f, name: user.name || '', email: user.email || '' }));
        }
    }, [profile, user]);

    const set = (key, val) => setForm(f => ({ ...f, [key]: val }));

    const handleSave = async () => {
        setSaving(true);
        await updateProfile({
            full_name: form.name,
            phone: form.phone,
            qualifications: form.qualifications,
            experience: form.experience,
            bio: form.bio,
        });
        setSaving(false);
        setSaveMsg('Saved!');
        setTimeout(() => setSaveMsg(''), 2500);
    };

    const handleUpload = async (e) => {
        const file = e.target.files?.[0];
        if (!file) return;
        setUploading(true);
        await uploadDocument(file, '');
        setUploading(false);
        e.target.value = '';
    };

    const handleDownload = (doc) => {
        const url = doc.url;
        if (url) {
            const a = document.createElement('a');
            a.href = url; a.download = doc.name || 'download'; a.target = '_blank'; a.click();
        }
    };

    const handleDelete = async (doc) => {
        if (window.confirm(`Delete "${doc.name}"?`)) {
            await deleteDocument(doc.id);
        }
    };

    // Initials for avatar
    const initials = (form.name || user?.name || '?').split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase();
    const dept = user?.department || departmentId || '—';
    const role = user?.role || 'teacher';

    return (
        <DashboardLayout>
            <div className="mb-6">
                <h1 className="text-2xl font-bold text-gray-900">About Me</h1>
                <p className="text-sm text-gray-400 mt-0.5">Manage your profile and documents</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* ── Left: Avatar Card ─────────────────────────────────── */}
                <div className="lg:col-span-1">
                    <div className="bg-white rounded-2xl border border-gray-200 p-8 flex flex-col items-center text-center">
                        {/* Avatar circle */}
                        <div className="w-24 h-24 rounded-full bg-blue-700 flex items-center justify-center text-white text-3xl font-bold mb-4">
                            {initials}
                        </div>
                        <h2 className="text-xl font-bold text-gray-900">{form.name || '—'}</h2>
                        <p className="text-blue-600 font-medium text-sm mt-0.5">{dept}</p>
                        <div className="mt-4 text-sm text-gray-500 space-y-1">
                            <p>Role: <span className="font-medium text-gray-700 capitalize">{role}</span></p>
                            <p>Email: <span className="font-medium text-gray-700">{form.email}</span></p>
                        </div>
                    </div>
                </div>

                {/* ── Right panel ───────────────────────────────────────── */}
                <div className="lg:col-span-2 space-y-6">
                    {/* Personal Information */}
                    <div className="bg-white rounded-2xl border border-gray-200 p-6">
                        <h3 className="text-base font-bold text-gray-900 flex items-center gap-2 mb-5">
                            <span className="text-blue-600">👤</span> Personal Information
                        </h3>

                        {pLoading ? (
                            <div className="flex justify-center py-8">
                                <Loader2 className="w-6 h-6 animate-spin text-blue-500" />
                            </div>
                        ) : (
                            <>
                                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                    <div>
                                        <label className="text-xs font-semibold text-gray-500 block mb-1">Full Name</label>
                                        <input value={form.name} onChange={e => set('name', e.target.value)} className={inputCls} />
                                    </div>
                                    <div>
                                        <label className="text-xs font-semibold text-gray-500 block mb-1">Email</label>
                                        <input value={form.email} disabled className={`${inputCls} bg-gray-50 text-gray-400 cursor-not-allowed`} />
                                    </div>
                                    <div>
                                        <label className="text-xs font-semibold text-gray-500 block mb-1">Phone</label>
                                        <input value={form.phone} onChange={e => set('phone', e.target.value)} className={inputCls} placeholder="e.g., 9890524254" />
                                    </div>
                                    <div>
                                        <label className="text-xs font-semibold text-gray-500 block mb-1">Department</label>
                                        <input value={dept} disabled className={`${inputCls} bg-gray-50 text-gray-400 cursor-not-allowed`} />
                                    </div>
                                    <div>
                                        <label className="text-xs font-semibold text-gray-500 block mb-1">Qualifications</label>
                                        <input value={form.qualifications} onChange={e => set('qualifications', e.target.value)} className={inputCls} placeholder="e.g., M.Tech, PhD" />
                                    </div>
                                    <div>
                                        <label className="text-xs font-semibold text-gray-500 block mb-1">Years of Experience</label>
                                        <input value={form.experience} onChange={e => set('experience', e.target.value)} className={inputCls} placeholder="e.g., 5" type="number" min={0} />
                                    </div>
                                </div>
                                <div className="mt-4">
                                    <label className="text-xs font-semibold text-gray-500 block mb-1">Bio</label>
                                    <textarea
                                        value={form.bio}
                                        onChange={e => set('bio', e.target.value)}
                                        rows={4} placeholder="Tell us about yourself..."
                                        className={`${inputCls} resize-none`}
                                    />
                                </div>

                                <div className="mt-5 flex items-center gap-3">
                                    <button onClick={handleSave} disabled={saving}
                                        className="flex items-center gap-2 px-5 py-2.5 bg-[#1a2b4b] text-white rounded-xl text-sm font-semibold disabled:opacity-60 hover:bg-[#243557]">
                                        {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                                        Save Changes
                                    </button>
                                    {saveMsg && <span className="text-green-600 text-sm font-medium">{saveMsg}</span>}
                                </div>
                            </>
                        )}
                    </div>

                    {/* My Documents */}
                    <div className="bg-white rounded-2xl border border-gray-200 p-6">
                        <div className="flex items-center justify-between mb-5">
                            <h3 className="text-base font-bold text-gray-900 flex items-center gap-2">
                                <FileText className="w-5 h-5 text-blue-600" /> My Documents
                            </h3>
                            <button onClick={() => fileRef.current?.click()} disabled={uploading}
                                className="flex items-center gap-2 px-4 py-2 bg-[#1a2b4b] text-white rounded-xl text-sm font-medium hover:bg-[#243557] disabled:opacity-60">
                                {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
                                Upload Document
                            </button>
                            <input ref={fileRef} type="file" className="hidden" onChange={handleUpload} />
                        </div>

                        {dLoading ? (
                            <div className="flex justify-center py-8">
                                <Loader2 className="w-6 h-6 animate-spin text-blue-500" />
                            </div>
                        ) : documents.length === 0 ? (
                            <div className="flex flex-col items-center py-10 text-gray-400">
                                <FileText className="w-12 h-12 mb-2 opacity-30" />
                                <p className="text-sm">No documents uploaded yet</p>
                            </div>
                        ) : (
                            <div className="space-y-2">
                                {documents.map(doc => (
                                    <div key={doc.id}
                                        className="flex items-center gap-3 px-4 py-3 rounded-xl border border-gray-100 hover:bg-gray-50 transition-colors">
                                        {/* Icon */}
                                        <div className="w-9 h-9 bg-blue-50 rounded-lg flex items-center justify-center flex-shrink-0">
                                            <FileText className="w-5 h-5 text-blue-600" />
                                        </div>
                                        {/* File info */}
                                        <div className="flex-1 min-w-0">
                                            <p className="text-sm font-medium text-gray-900 truncate">{doc.name}</p>
                                            <p className="text-xs text-gray-400">{formatSize(doc.size)} • {fmtDate(doc.createdAt)}</p>
                                        </div>
                                        {/* Actions */}
                                        <button onClick={() => handleDownload(doc)}
                                            className="w-8 h-8 flex items-center justify-center text-gray-400 hover:text-blue-600 rounded-lg hover:bg-blue-50 transition-colors"
                                            title="Download">
                                            <Download className="w-4 h-4" />
                                        </button>
                                        <button onClick={() => handleDelete(doc)}
                                            className="w-8 h-8 flex items-center justify-center text-gray-400 hover:text-red-500 rounded-lg hover:bg-red-50 transition-colors"
                                            title="Delete">
                                            <Trash2 className="w-4 h-4" />
                                        </button>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </DashboardLayout>
    );
}
