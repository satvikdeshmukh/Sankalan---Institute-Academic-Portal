import React from 'react';
import DashboardLayout from '../../components/layout/DashboardLayout.jsx';
import ExtraCurricular from './ExtraCurricular.jsx';
import { useStudents } from '../../hooks/useStudents.js';
import { useAuth } from '../../contexts/AuthContext.jsx';

export default function TeacherExtraCurricular() {
    const { user, departmentId } = useAuth();
    const { students } = useStudents(user?.id, departmentId);

    return (
        <DashboardLayout>
            <ExtraCurricular students={students} userId={user?.id} />
        </DashboardLayout>
    );
}
