import React, { useState, useMemo, useEffect } from 'react';
import { useAuth } from '../../contexts/AuthContext.jsx';
import { useStudents } from '../../hooks/useStudents.js';
import { useReports } from '../../hooks/useReports.js';
import { useActivities } from '../../hooks/useActivities.js';
import { supabase } from '../../lib/supabase.js';
import { generateAnnualReportPDF, generateStudentReportPDF } from '../../utils/pdfGenerator.js';
import DashboardLayout from '../../components/layout/DashboardLayout.jsx';
import {
    BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
    LineChart, Line, PieChart, Pie, Cell, Legend,
} from 'recharts';
import { Download, Plus, X, Save, User, BarChart2 } from 'lucide-react';

/* ── Helpers ─────────────────────────────────────────────────── */
const MONTH_FIELDS = ['jan_att', 'feb_att', 'mar_att', 'apr_att', 'may_att', 'jun_att', 'jul_att', 'aug_att', 'sep_att', 'oct_att', 'nov_att', 'dec_att'];
const MONTH_LABELS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

// Compute average attendance from monthly fields (same logic as TeacherStudents)
function calcAvgAtt(student) {
    if (!student) return 0;
    const vals = MONTH_FIELDS
        .map(k => Number(student[k]))
        .filter(v => !isNaN(v) && v > 0);
    if (vals.length === 0) return Number(student.avg_attendance ?? student.attendance) || 0;
    return Math.round(vals.reduce((a, b) => a + b, 0) / vals.length);
}

function avgMonthly(students) {
    return MONTH_LABELS.map((m, i) => {
        // Only count students who have actual attendance recorded for that month (> 0)
        const vals = students
            .map(s => s[MONTH_FIELDS[i]])
            .filter(v => v != null && !isNaN(Number(v)) && Number(v) > 0)
            .map(Number);
        return {
            month: m,
            attendance: vals.length
                ? Math.round(vals.reduce((a, b) => a + b, 0) / vals.length)
                : 0
        };
    }).filter(d => d.attendance > 0); // only show months that have any data
}

function perfTrend(students) {
    const months = ['Aug', 'Sep', 'Oct', 'Nov', 'Dec', 'Jan'];

    if (!students.length) {
        return months.map(m => ({ month: m, value: 0 }));
    }

    return months.map((m, i) => {
        const avg =
            students.reduce((sum, s) => sum + (Number(s.attendance) || 0), 0) /
            students.length;

        return {
            month: m,
            value: Math.round(avg - 5 + i * 2)
        };
    });
}

const inputCls = "w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-gray-50 placeholder-gray-400";

/* ══ Class Report ══════════════════════════════════════ */
function ClassReport({ students, reports, createReport, userId, teacherName }) {
    const [year, setYear] = useState('all');
    const [title, setTitle] = useState('');
    const [desc, setDesc] = useState('');
    const [charts, setCharts] = useState({ attendance: true, performance: true, subjectComparison: false });
    const [saving, setSaving] = useState(false);

    // Custom cols from Supabase teacher_custom_cols for selected year
    const [supabaseCols, setSupabaseCols] = useState([]);
    // Set of keys the teacher has TOGGLED OFF (excluded from chart)
    const [removedKeys, setRemovedKeys] = useState(new Set());

    const filtered = year === 'all' ? students : students.filter(s => String(s.year) === year);
    const attData = useMemo(() => avgMonthly(filtered), [filtered]); // all months, no slice cap
    const perfData = useMemo(() => perfTrend(filtered), [filtered]);
    const toggleChart = k => setCharts(p => ({ ...p, [k]: !p[k] }));

    // ─ Fetch custom cols from API when year or userId changes ─
    useEffect(() => {
        if (!userId) return;
        const fetchCols = async () => {
            try {
                const params = new URLSearchParams();
                if (year !== 'all') params.append('year', year);
                params.append('semester', '1');
                const { apiFetch } = await import('../../lib/api.js');
                const data = await apiFetch(`/custom-cols?${params}`);
                const unique = [...new Set((data || []).map(r => r.colName || r.col_name))];
                setSupabaseCols(unique);
            } catch { setSupabaseCols([]); }
        };
        fetchCols();
    }, [userId, year]);

    // Reset removed keys when year changes
    useEffect(() => { setRemovedKeys(new Set()); }, [year]);

    // Auto-detect keys from student.custom_data for the filtered students
    const autoSubjectKeys = useMemo(() => {
        const seen = new Set();
        filtered.forEach(s => Object.keys(s.custom_data || {}).forEach(k => seen.add(k)));
        return [...seen];
    }, [filtered]);

    // Merge Supabase cols + auto-detected cols (deduplicated)
    const allSubjectKeys = useMemo(() => {
        const merged = new Set([...supabaseCols, ...autoSubjectKeys]);
        return [...merged];
    }, [supabaseCols, autoSubjectKeys]);

    // Active keys = all minus removed
    const activeKeys = allSubjectKeys.filter(k => !removedKeys.has(k));

    const toggleKey = (k) => {
        setRemovedKeys(prev => {
            const next = new Set(prev);
            next.has(k) ? next.delete(k) : next.add(k);
            return next;
        });
    };

    // Subject Comparison data — only active (non-removed) keys
    const subjectCompData = useMemo(() =>
        activeKeys.map(key => {
            const vals = filtered
                .map(s => Number(s.custom_data?.[key] ?? ''))
                .filter(v => !isNaN(v) && v > 0);
            return {
                subject: key,
                average: vals.length ? parseFloat((vals.reduce((a, b) => a + b, 0) / vals.length).toFixed(1)) : 0,
            };
        }),
        [filtered, activeKeys]);

    const handleDownload = () => {
        const avgAttendance = filtered.length
            ? Math.round(filtered.reduce((sum, st) => sum + (Number(st.attendance) || 0), 0) / filtered.length)
            : 0;
        generateAnnualReportPDF({
            title: title || 'Class Report',
            content: desc,
            generatedBy: teacherName || 'Teacher',
            charts: { attendance: attData },
            students: filtered,
            summary: {
                totalStudents: filtered.length,
                avgAttendance,
                highPerformers: filtered.filter(s => Number(s.attendance) >= 75).length,
                lowAttendance: filtered.filter(s => Number(s.attendance) < 50).length,
            },
            subjectCompData,
            performanceData: perfData,
            visibleCharts: charts,
        });
    };

    const handleSave = async () => {
        if (!title) return;
        setSaving(true);
        await createReport({ title, content: desc, chart_data: { attendance: attData, trend: perfData }, reporter_role: 'teacher' });
        setSaving(false);
        setTitle(''); setDesc('');
    };

    const ordinal = { '1': '1st', '2': '2nd', '3': '3rd', '4': '4th' };

    return (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* LEFT — Config */}
            <div className="bg-white rounded-2xl border border-gray-200 p-6 space-y-5">
                <h2 className="font-bold text-gray-900">Report Configuration</h2>

                <div>
                    <label className="text-xs font-semibold text-gray-500 block mb-1">Select Year</label>
                    <select value={year} onChange={e => setYear(e.target.value)} className={inputCls}>
                        <option value="all">All Years</option>
                        {[1, 2, 3, 4].map(y => <option key={y} value={String(y)}>{ordinal[y]} Year</option>)}
                    </select>
                    <p className="text-xs text-gray-400 mt-1">{filtered.length} students selected</p>
                </div>

                <div>
                    <label className="text-xs font-semibold text-gray-500 block mb-1">Report Title</label>
                    <input value={title} onChange={e => setTitle(e.target.value)} placeholder="e.g., Q1 Performance Report" className={inputCls} />
                </div>

                <div>
                    <label className="text-xs font-semibold text-gray-500 block mb-1">Report Description</label>
                    <textarea value={desc} onChange={e => setDesc(e.target.value)} rows={3} placeholder="Add notes or description for this report..." className={`${inputCls} resize-none`} />
                </div>

                <div>
                    <label className="text-xs font-semibold text-gray-500 block mb-2">Select Charts</label>
                    {[{ key: 'attendance', label: 'Attendance Analysis' }, { key: 'performance', label: 'Performance Trend' }, { key: 'subjectComparison', label: 'Subject Comparison' }].map(opt => (
                        <label key={opt.key} className="flex items-center gap-2 mb-2 cursor-pointer">
                            <input type="checkbox" checked={charts[opt.key]} onChange={() => toggleChart(opt.key)}
                                className="w-4 h-4 rounded accent-blue-600" />
                            <span className="text-sm text-gray-700">{opt.label}</span>
                        </label>
                    ))}
                </div>

                {/* Subject column chips — shown when Subject Comparison is enabled */}
                {charts.subjectComparison && (
                    <div>
                        {allSubjectKeys.length === 0 ? (
                            <p className="text-[10px] text-gray-400">
                                No custom columns found for {year === 'all' ? 'any year' : `${ordinal[year]} year`}.
                                Add columns via Students → Semesters → Add Column.
                            </p>
                        ) : (
                            <>
                                <div className="flex items-center justify-between mb-1.5">
                                    <p className="text-[10px] font-semibold text-gray-500">
                                        Custom columns for {year === 'all' ? 'all years' : `${ordinal[year]} year`}
                                        <span className="font-normal text-gray-400 ml-1">— click to toggle</span>
                                    </p>
                                    {removedKeys.size > 0 && (
                                        <button
                                            onClick={() => setRemovedKeys(new Set())}
                                            className="text-[10px] text-blue-500 hover:underline"
                                        >Reset all</button>
                                    )}
                                </div>
                                <div className="flex flex-wrap gap-1.5">
                                    {allSubjectKeys.map(k => {
                                        const active = !removedKeys.has(k);
                                        return (
                                            <button
                                                key={k}
                                                onClick={() => toggleKey(k)}
                                                title={active ? 'Click to exclude from chart' : 'Click to include in chart'}
                                                className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium border transition-all ${active
                                                    ? 'bg-purple-50 border-purple-200 text-purple-700 hover:bg-purple-100'
                                                    : 'bg-gray-100 border-gray-200 text-gray-400 line-through hover:bg-gray-200'
                                                    }`}
                                            >
                                                {k}
                                                <span className={`text-[9px] ml-0.5 ${active ? 'text-purple-400' : 'text-gray-300'}`}>
                                                    {active ? '✕' : '+'}
                                                </span>
                                            </button>
                                        );
                                    })}
                                </div>
                            </>
                        )}
                    </div>
                )}

                <div className="flex gap-3 pt-2">
                    <button onClick={handleSave} disabled={saving || !title}
                        className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-[#1a2b4b] text-white rounded-lg text-sm font-medium disabled:opacity-50">
                        <Save className="w-4 h-4" /> {saving ? 'Saving…' : 'Save Report'}
                    </button>
                </div>
            </div>

            {/* RIGHT — Preview */}
            <div className="bg-white rounded-2xl border border-gray-200 p-6">
                <div className="flex items-center justify-between mb-5">
                    <h2 className="font-bold text-gray-900">Report Preview</h2>
                    <button onClick={handleDownload}
                        className="flex items-center gap-1.5 px-3 py-1.5 border border-gray-200 rounded-lg text-sm hover:bg-gray-50">
                        <Download className="w-4 h-4" /> Download PDF
                    </button>
                </div>

                {charts.attendance && (
                    <div className="mb-6">
                        <p className="text-xs font-semibold text-gray-500 mb-2">Attendance Analysis (Monthly Average)</p>
                        <ResponsiveContainer width="100%" height={160}>
                            <BarChart data={attData.length ? attData : MONTH_LABELS.slice(0, 3).map(m => ({ month: m, attendance: 0 }))} margin={{ left: -25, bottom: 2 }}>
                                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                                <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
                                <YAxis domain={[0, 100]} tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
                                <Tooltip contentStyle={{ borderRadius: 8, border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)', fontSize: 12 }} />
                                <Bar dataKey="attendance" fill="#1e3a8a" radius={[4, 4, 0, 0]} maxBarSize={40} />
                            </BarChart>
                        </ResponsiveContainer>
                    </div>
                )}

                {charts.performance && (
                    <div className="mb-6">
                        <p className="text-xs font-semibold text-gray-500 mb-2">Performance Trend</p>
                        <ResponsiveContainer width="100%" height={160}>
                            <LineChart data={perfData} margin={{ left: -25, bottom: 2 }}>
                                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                                <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
                                <YAxis domain={[0, 100]} tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
                                <Tooltip contentStyle={{ borderRadius: 8, border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)', fontSize: 12 }} />
                                <Line type="monotone" dataKey="value" stroke="#0891b2" strokeWidth={2} dot={{ r: 4, fill: '#0891b2' }} activeDot={{ r: 6 }} />
                            </LineChart>
                        </ResponsiveContainer>
                    </div>
                )}

                {charts.subjectComparison && (
                    <div>
                        <p className="text-xs font-semibold text-gray-500 mb-2">Subject Comparison (Class Average)</p>
                        {activeKeys.length === 0 ? (
                            <div className="h-[140px] flex items-center justify-center text-center">
                                <p className="text-sm text-gray-300">
                                    {allSubjectKeys.length === 0
                                        ? 'No custom columns found. Add columns in Students → Semesters.'
                                        : 'All columns excluded. Click a chip on the left to include it.'}
                                </p>
                            </div>
                        ) : (
                            <ResponsiveContainer width="100%" height={180}>
                                <BarChart data={subjectCompData} margin={{ left: -25, bottom: 2 }}>
                                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                                    <XAxis dataKey="subject" tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
                                    <YAxis tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
                                    <Tooltip contentStyle={{ borderRadius: 8, border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)', fontSize: 12 }} formatter={val => [val, 'Class Avg']} />
                                    <Bar dataKey="average" fill="#7c3aed" radius={[4, 4, 0, 0]} maxBarSize={50} />
                                </BarChart>
                            </ResponsiveContainer>
                        )}
                    </div>
                )}
            </div>
        </div>
    );
}

/* EC months mapping */
const EC_MONTH_KEYS = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'];
const EC_MONTH_LABELS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

/* ── Single Student Report ────────────────────────────────────── */
function SingleStudentReport({ students, createReport, userId, teacherName }) {
    const [studentId, setStudentId] = useState('');
    const [search, setSearch] = useState('');
    const [showSearch, setShowSearch] = useState(false);
    const [title, setTitle] = useState('');
    const [desc, setDesc] = useState('');
    const [addFields, setAddFields] = useState([]);
    const [subjects, setSubjects] = useState([
        { _id: 1, name: 'Mathematics', score: '', total: 100 },
        { _id: 2, name: 'Science', score: '', total: 100 },
        { _id: 3, name: 'English', score: '', total: 100 },
    ]);
    const [viz, setViz] = useState({ pie: true, trend: true, marks: true });
    const [saving, setSaving] = useState(false);
    const nextId = React.useRef(4);
    const searchRef = React.useRef(null);

    // Extra-curricular data
    const { getMonthTotal } = useActivities(userId);

    const student = students.find(s => s.id === studentId);

    const monthData = useMemo(() => {
        if (!student) return [];
        return MONTH_LABELS.map((m, i) => ({ month: m, attendance: Number(student[MONTH_FIELDS[i]]) || 0 })).filter(d => d.attendance > 0);
    }, [student]);

    const marksData = useMemo(() =>
        subjects.filter(s => s.name && s.score).map(s => ({ subject: s.name, marks: Number(s.score) || 0 })),
        [subjects]);

    // Progress Trend: monthly extra-curricular credits for the selected student
    const ecTrendData = useMemo(() => {
        if (!student) return [];
        return EC_MONTH_KEYS
            .map((m, i) => ({ month: EC_MONTH_LABELS[i], credits: getMonthTotal(student.id, m) }))
            .filter(d => d.credits > 0);
    }, [student, getMonthTotal]);

    const present = student ? calcAvgAtt(student) : 0;
    const absent = 100 - present;
    const pieData = [{ name: 'Present', value: present }, { name: 'Absent', value: absent }];

    const addField = () => setAddFields(p => [...p, { _id: nextId.current++, label: '', value: '' }]);
    const addSubject = () => setSubjects(p => [...p, { _id: nextId.current++, name: '', score: '', total: 100 }]);

    const handleSave = async () => {
        if (!studentId || !title) return;
        setSaving(true);
        await createReport({
            title, content: desc,
            chart_data: { monthly: monthData, marks: marksData, trend: ecTrendData, additionalFields: addFields },
            reporter_role: 'teacher',
        });
        setSaving(false);
    };

    const handleDownload = () => {
        if (!student) return;
        generateStudentReportPDF({
            student,
            teacherName,
            title: title || `${student.name} Report`,
            desc,
            monthData,
            marksData,
            ecTrendData,
            subjects,
            addFields,
        });
    };

    return (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* LEFT */}
            <div className="bg-white rounded-2xl border border-gray-200 p-6 space-y-5 overflow-y-auto max-h-[80vh]">
                <h2 className="font-bold text-gray-900 flex items-center gap-2"><User className="w-5 h-5" /> Single Student Report</h2>

                {/* Search Student — custom searchable combobox */}
                <div className="relative" ref={searchRef}>
                    <label className="text-xs font-semibold text-gray-500 block mb-1">Search Student</label>

                    {/* Text input that doubles as search + display */}
                    <div className="relative">
                        <input
                            type="text"
                            value={showSearch ? search : (students.find(s => s.id === studentId)?.name
                                ? `${students.find(s => s.id === studentId).name}${students.find(s => s.id === studentId).student_id ? ` (${students.find(s => s.id === studentId).student_id})` : ''}` : '')}
                            onChange={e => { setSearch(e.target.value); setShowSearch(true); }}
                            onFocus={() => { setSearch(''); setShowSearch(true); }}
                            onBlur={() => setTimeout(() => setShowSearch(false), 150)}
                            placeholder="Search by name or student ID…"
                            className={`${inputCls} pr-8`}
                        />
                        {/* Chevron icon */}
                        <span className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none">
                            <svg width="14" height="14" viewBox="0 0 20 20" fill="currentColor">
                                <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
                            </svg>
                        </span>
                    </div>

                    {/* Filtered dropdown list */}
                    {showSearch && (
                        <div className="absolute z-30 w-full bg-white border border-gray-200 rounded-xl shadow-lg mt-1 max-h-52 overflow-y-auto">
                            {/* "No selection" option */}
                            <button
                                onMouseDown={() => { setStudentId(''); setSearch(''); setShowSearch(false); }}
                                className="w-full text-left px-4 py-2.5 text-sm text-gray-400 hover:bg-gray-50 border-b border-gray-100"
                            >
                                — Select a student —
                            </button>
                            {students
                                .filter(s => {
                                    const q = search.toLowerCase();
                                    return !q ||
                                        s.name?.toLowerCase().includes(q) ||
                                        String(s.student_id || '').toLowerCase().includes(q);
                                })
                                .map(s => (
                                    <button
                                        key={s.id}
                                        onMouseDown={() => { setStudentId(s.id); setSearch(''); setShowSearch(false); }}
                                        className={`w-full text-left px-4 py-2.5 text-sm hover:bg-blue-50 transition-colors ${s.id === studentId ? 'bg-blue-50 text-blue-700 font-medium' : 'text-gray-700'
                                            }`}
                                    >
                                        <span className="font-medium">{s.name}</span>
                                        {s.student_id && <span className="ml-2 text-xs text-gray-400">({s.student_id})</span>}
                                        <span className="ml-2 text-xs text-gray-300">Yr {s.year}</span>
                                    </button>
                                ))
                            }
                            {students.filter(s => {
                                const q = search.toLowerCase();
                                return !q || s.name?.toLowerCase().includes(q) || String(s.student_id || '').toLowerCase().includes(q);
                            }).length === 0 && (
                                    <p className="px-4 py-3 text-sm text-gray-400">No students match "{search}"</p>
                                )}
                        </div>
                    )}
                </div>

                {/* Student Details */}
                {student && (
                    <div className="grid grid-cols-2 gap-3 bg-gray-50 rounded-xl p-4 text-sm">
                        <div><p className="text-xs text-gray-400">Name</p><p className="font-semibold text-gray-900">{student.name}</p></div>
                        <div><p className="text-xs text-gray-400">Student ID</p><p className="font-semibold text-gray-900">{student.student_id || '—'}</p></div>
                        <div><p className="text-xs text-gray-400">Year</p><p className="font-semibold text-gray-900">{student.year}</p></div>
                        <div><p className="text-xs text-gray-400">Avg Attendance</p><p className="font-semibold text-gray-900">{calcAvgAtt(student)}%</p></div>
                        <div className="col-span-2"><p className="text-xs text-gray-400">Email</p><p className="font-semibold text-gray-900">{student.email || '—'}</p></div>
                    </div>
                )}

                <div>
                    <label className="text-xs font-semibold text-gray-500 block mb-1">Report Title</label>
                    <input value={title} onChange={e => setTitle(e.target.value)} placeholder="e.g., Monthly Progress Report" className={inputCls} />
                </div>
                <div>
                    <label className="text-xs font-semibold text-gray-500 block mb-1">Description / Notes</label>
                    <textarea value={desc} onChange={e => setDesc(e.target.value)} rows={3} placeholder="Add notes about the student's performance..." className={`${inputCls} resize-none`} />
                </div>

                {/* Additional Information */}
                <div>
                    <div className="flex items-center justify-between mb-2">
                        <label className="text-xs font-semibold text-gray-500">Additional Information</label>
                        <button onClick={addField} className="flex items-center gap-1 text-xs text-blue-600 hover:text-blue-800 font-medium"><Plus className="w-3.5 h-3.5" /> Add Field</button>
                    </div>
                    {addFields.map((f) => (
                        <div key={f._id} className="flex gap-2 mb-2">
                            <input value={f.label} onChange={e => setAddFields(p => p.map(x => x._id === f._id ? { ...x, label: e.target.value } : x))} placeholder="Label" className={`${inputCls} flex-1`} />
                            <input value={f.value} onChange={e => setAddFields(p => p.map(x => x._id === f._id ? { ...x, value: e.target.value } : x))} placeholder="Value" className={`${inputCls} flex-1`} />
                            <button onClick={() => setAddFields(p => p.filter(x => x._id !== f._id))} className="text-red-400"><X className="w-4 h-4" /></button>
                        </div>
                    ))}
                </div>

                {/* Subject Marks */}
                <div>
                    <div className="flex items-center justify-between mb-2">
                        <label className="text-xs font-semibold text-gray-500">Subject Marks</label>
                        <button onClick={addSubject} className="flex items-center gap-1 text-xs text-blue-600 font-medium"><Plus className="w-3.5 h-3.5" /> Add Subject</button>
                    </div>
                    {subjects.map((s) => {
                        const pct = s.score && s.total ? Math.round((Number(s.score) / Number(s.total)) * 100) : null;
                        const badgeColor = pct === null ? 'bg-gray-100 text-gray-400' : pct >= 60 ? 'bg-green-100 text-green-700' : pct >= 40 ? 'bg-amber-100 text-amber-700' : 'bg-red-100 text-red-600';
                        return (
                            <div key={s._id} className="flex items-center gap-2 mb-2">
                                <input value={s.name} onChange={e => setSubjects(p => p.map(x => x._id === s._id ? { ...x, name: e.target.value } : x))} placeholder="Subject name" className={`${inputCls} flex-[3] min-w-0`} />
                                <input type="number" min="0" value={s.score} onChange={e => setSubjects(p => p.map(x => x._id === s._id ? { ...x, score: e.target.value } : x))} placeholder="Score" className={`${inputCls} flex-1 min-w-0 text-center`} />
                                <span className="text-gray-400 text-sm shrink-0">/</span>
                                <input type="number" min="1" value={s.total} onChange={e => setSubjects(p => p.map(x => x._id === s._id ? { ...x, total: e.target.value } : x))} className={`${inputCls} flex-1 min-w-0 text-center`} />
                                <button onClick={() => setSubjects(p => p.filter(x => x._id !== s._id))} className="text-gray-400 hover:text-red-500 shrink-0"><X className="w-4 h-4" /></button>
                            </div>
                        );
                    })}
                </div>

                {/* Visualizations */}
                <div>
                    <label className="text-xs font-semibold text-gray-500 block mb-2">Select Visualizations</label>
                    {[{ key: 'pie', label: 'Attendance (Pie Chart)' }, { key: 'trend', label: 'Progress Trend' }, { key: 'marks', label: 'Subject Marks' }].map(opt => (
                        <label key={opt.key} className="flex items-center gap-2 mb-2 cursor-pointer">
                            <input type="checkbox" checked={viz[opt.key]} onChange={() => setViz(p => ({ ...p, [opt.key]: !p[opt.key] }))} className="w-4 h-4 rounded accent-blue-600" />
                            <span className="text-sm text-gray-700">{opt.label}</span>
                        </label>
                    ))}
                </div>

                <button onClick={handleSave} disabled={saving || !studentId || !title}
                    className="w-full py-3 bg-[#1a2b4b] text-white rounded-xl text-sm font-semibold disabled:opacity-50">
                    {saving ? 'Saving…' : 'Save Report'}
                </button>
            </div>

            {/* RIGHT — Preview */}
            <div className="bg-white rounded-2xl border border-gray-200 p-6 overflow-y-auto max-h-[80vh]">
                <div className="flex items-center justify-between mb-4">
                    <h2 className="font-bold text-gray-900">Preview</h2>
                    <button onClick={handleDownload} disabled={!student}
                        className="flex items-center gap-1.5 px-3 py-1.5 border border-gray-200 rounded-lg text-sm hover:bg-gray-50 disabled:opacity-40">
                        <Download className="w-4 h-4" /> Download PDF
                    </button>
                </div>

                <p className="text-xs font-semibold text-gray-500 mb-3">Attendance</p>
                <div className="grid grid-cols-2 gap-4 mb-6">
                    {/* Donut */}
                    {viz.pie && (
                        <div>
                            <p className="text-[11px] text-center text-gray-400 mb-1">Overall Attendance</p>
                            <ResponsiveContainer width="100%" height={130}>
                                <PieChart>
                                    <Pie data={pieData} cx="50%" cy="50%" innerRadius={40} outerRadius={60} dataKey="value" startAngle={90} endAngle={-270}>
                                        <Cell fill="#16a34a" /><Cell fill="#ef4444" />
                                    </Pie>
                                    <Legend iconType="square" iconSize={8} formatter={(v, e) => <span style={{ fontSize: 10, color: '#6b7280' }}>{v}</span>} />
                                </PieChart>
                            </ResponsiveContainer>
                        </div>
                    )}
                    {/* Monthly bar */}
                    <div>
                        <p className="text-[11px] text-center text-gray-400 mb-1">Monthly Attendance</p>
                        <ResponsiveContainer width="100%" height={130}>
                            <BarChart data={monthData.slice(0, 6).length ? monthData.slice(0, 6) : MONTH_LABELS.slice(0, 3).map(m => ({ month: m, attendance: 0 }))} margin={{ left: -28 }}>
                                <XAxis dataKey="month" tick={{ fontSize: 10, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
                                <YAxis domain={[0, 100]} tick={{ fontSize: 10, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
                                <Bar dataKey="attendance" fill="#16a34a" radius={[3, 3, 0, 0]} maxBarSize={30} />
                            </BarChart>
                        </ResponsiveContainer>
                    </div>
                </div>

                {/* Subject Marks — always visible, real-time */}
                {viz.marks && (
                    <div className="mb-6">
                        <div className="flex items-center justify-between mb-2">
                            <p className="text-xs font-semibold text-gray-500">Subject Marks</p>
                            {marksData.length === 0 && (
                                <span className="text-[10px] text-gray-400 italic">Enter scores to see chart</span>
                            )}
                        </div>
                        <ResponsiveContainer width="100%" height={150}>
                            <BarChart
                                data={marksData.length > 0
                                    ? marksData
                                    : subjects.filter(s => s.name).map(s => ({ subject: s.name || '—', marks: 0 }))
                                }
                                margin={{ left: -25 }}
                            >
                                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                                <XAxis dataKey="subject" tick={{ fontSize: 10, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
                                <YAxis domain={[0, 100]} tick={{ fontSize: 10, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
                                <Tooltip
                                    contentStyle={{ borderRadius: 8, border: 'none', fontSize: 11 }}
                                    formatter={(v) => [`${v}`, 'Marks']}
                                />
                                <Bar dataKey="marks" fill="#1e3a8a" radius={[4, 4, 0, 0]} maxBarSize={40}
                                    label={{ position: 'top', fontSize: 10, fill: '#6b7280', formatter: (v) => v > 0 ? v : '' }}
                                />
                            </BarChart>
                        </ResponsiveContainer>
                    </div>
                )}

                {/* Progress Trend — Extra Curricular Monthly Credits */}
                {viz.trend && (
                    <div>
                        <p className="text-xs font-semibold text-gray-500 mb-1">Progress Trend (Extra Curricular Credits)</p>
                        {ecTrendData.length === 0 ? (
                            <div className="h-[130px] flex items-center justify-center">
                                <p className="text-sm text-gray-300">
                                    {student ? 'No extra-curricular credits recorded yet' : 'Select a student to view trend'}
                                </p>
                            </div>
                        ) : (
                            <ResponsiveContainer width="100%" height={130}>
                                <LineChart data={ecTrendData} margin={{ left: -25 }}>
                                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                                    <XAxis dataKey="month" tick={{ fontSize: 10, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
                                    <YAxis tick={{ fontSize: 10, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
                                    <Tooltip contentStyle={{ borderRadius: 8, border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)', fontSize: 12 }} formatter={val => [val, 'Credits']} />
                                    <Line type="monotone" dataKey="credits" stroke="#0891b2" strokeWidth={2} dot={{ r: 3, fill: '#0891b2' }} activeDot={{ r: 5 }} />
                                </LineChart>
                            </ResponsiveContainer>
                        )}
                    </div>
                )}
            </div>
        </div>
    );
}

/* ── Main Page ────────────────────────────────────────────────── */
export default function TeacherReports() {
    const { user, departmentId } = useAuth();
    const { students = [] } = useStudents(user?.id, departmentId);
    const { reports, createReport } = useReports(user?.id, 'teacher', departmentId);
    const [tab, setTab] = useState('class');

    return (
        <DashboardLayout>
            <div className="mb-6">
                <h1 className="text-2xl font-bold text-gray-900">Report Generation</h1>
                <p className="text-sm text-gray-400 mt-0.5">Create customized reports with data visualization</p>
            </div>

            {/* Tab switcher */}
            <div className="flex gap-1 mb-6 border-b border-gray-200">
                {[
                    { key: 'class', label: 'Class Report', icon: BarChart2 },
                    { key: 'single', label: 'Single Student Report', icon: User },
                ].map(t => (
                    <button key={t.key} onClick={() => setTab(t.key)}
                        className={`flex items-center gap-1.5 px-4 py-2.5 text-sm font-medium border-b-2 transition-colors -mb-px ${tab === t.key ? 'border-blue-600 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700'
                            }`}>
                        <t.icon className="w-4 h-4" /> {t.label}
                    </button>
                ))}
            </div>

            {tab === 'class'
                ? <ClassReport students={students} reports={reports} createReport={createReport} userId={user?.id} teacherName={user?.name || user?.email || 'Teacher'} />
                : <SingleStudentReport students={students} createReport={createReport} userId={user?.id} teacherName={user?.name || user?.email || 'Teacher'} />
            }
        </DashboardLayout>
    );
}
