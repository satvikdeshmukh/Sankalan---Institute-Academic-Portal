import React, { useState, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext.jsx';
import { useStudents } from '../../hooks/useStudents.js';
import { useCourses } from '../../hooks/useCourses.js';
import { supabase } from '../../lib/supabase.js';
import DashboardLayout from '../../components/layout/DashboardLayout.jsx';
import { Plus, Trash2, LayoutList, BookOpen, Users, Pencil, X } from 'lucide-react';

// First 3 shown by default; full set used for normalization
const ALL_MONTH_COLS = [
    { key: 'jan_att', label: 'January Att.' }, { key: 'feb_att', label: 'February Att.' },
    { key: 'mar_att', label: 'March Att.' }, { key: 'apr_att', label: 'April Att.' },
    { key: 'may_att', label: 'May Att.' }, { key: 'jun_att', label: 'June Att.' },
    { key: 'jul_att', label: 'July Att.' }, { key: 'aug_att', label: 'August Att.' },
    { key: 'sep_att', label: 'September Att.' }, { key: 'oct_att', label: 'October Att.' },
    { key: 'nov_att', label: 'November Att.' }, { key: 'dec_att', label: 'December Att.' },
];

function AttBar({ value }) {
    const pct = Math.min(100, Math.max(0, Number(value) || 0));
    const color = pct >= 75 ? '#16a34a' : pct >= 50 ? '#f59e0b' : '#ef4444';
    return (
        <div className="flex items-center gap-2 min-w-[80px]">
            <div className="flex-1 h-1.5 bg-gray-200 rounded-full overflow-hidden">
                <div style={{ width: `${pct}%`, backgroundColor: color }} className="h-full rounded-full" />
            </div>
            <span className="text-xs text-gray-600 w-8 text-right">{pct}%</span>
        </div>
    );
}

// Normalize a label for month matching (same as semester table)
const normalise = str => str.toLowerCase().replace(/att\.?/g, '').replace(/[\s._-]+/g, '').trim();

// Inline editable CustomCell — reads/writes student.custom_data[colLabel]
function CustomCell({ student, colLabel, onSave }) {
    const initial = student.custom_data?.[colLabel] ?? '';
    const [val, setVal] = React.useState(initial);
    const [saving, setSaving] = React.useState(false);

    const commit = async () => {
        if (val === (student.custom_data?.[colLabel] ?? '')) return;
        setSaving(true);
        await onSave(val);
        setSaving(false);
    };

    return (
        <input
            value={val}
            onChange={e => setVal(e.target.value)}
            onBlur={commit}
            onKeyDown={e => e.key === 'Enter' && e.target.blur()}
            disabled={saving}
            placeholder="—"
            className={`w-24 text-xs border rounded px-2 py-1 focus:outline-none focus:ring-1 focus:ring-blue-400 ${saving ? 'opacity-50 bg-gray-50' : 'border-gray-200 bg-white hover:border-blue-300'
                }`}
        />
    );
}

const inputCls = "w-full px-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white placeholder-gray-400";

export default function TeacherCourses() {
    const [searchParams] = useSearchParams();
    const { user, departmentId } = useAuth();
    const { students, updateStudent } = useStudents(user?.id, departmentId);
    const {
        courses, addCourse, updateCourse, deleteCourse,
        addStudentToCourse, removeStudentFromCourse,
        addCustomCol, removeCustomCol, hideCol
    } = useCourses(user?.id);

    // If a ?course=id param is present, auto-select that course
    const urlCourseId = searchParams.get('course');
    const [activeCourseId, setActiveCourseId] = useState(urlCourseId || null);

    // Course modals
    const [showAddCourse, setShowAddCourse] = useState(false);
    const [editCourse, setEditCourse] = useState(null);
    const [courseForm, setCourseForm] = useState({ name: '', description: '' });
    const [showManage, setShowManage] = useState(false);

    // Add Column
    const [showAddColPopover, setShowAddColPopover] = useState(false);
    const [newColName, setNewColName] = useState('');

    // Delete Column (multi-select)
    const [showDelColPopover, setShowDelColPopover] = useState(false);
    const [colsToDelete, setColsToDelete] = useState(new Set());

    // Edit row
    const [editingStudent, setEditingStudent] = useState(null);
    const [editForm, setEditForm] = useState({});
    const [editSaving, setEditSaving] = useState(false);

    // Sync URL param → active course
    React.useEffect(() => {
        if (urlCourseId) setActiveCourseId(urlCourseId);
    }, [urlCourseId]);

    const activeCourse = courses.find(c => c.id === activeCourseId) || courses[0];
    const courseStudents = useMemo(() =>
        activeCourse ? students.filter(s => activeCourse.studentIds.includes(s.id)) : [],
        [activeCourse, students]);

    /* ── Course CRUD ─────────────────────────────────────────── */
    const handleAddCourse = () => {
        if (!courseForm.name) return;
        if (editCourse) {
            updateCourse(editCourse.id, courseForm);
        } else {
            const c = addCourse(courseForm.name, courseForm.description);
            setActiveCourseId(c.id);
        }
        setCourseForm({ name: '', description: '' });
        setShowAddCourse(false); setEditCourse(null);
    };
    const openEditCourse = (c) => {
        setEditCourse(c); setCourseForm({ name: c.name, description: c.description });
        setShowAddCourse(true);
    };

    /* ── Column helpers ──────────────────────────────────────── */
    const handleAddCol = () => {
        if (newColName && activeCourse) addCustomCol(activeCourse.id, newColName);
        setNewColName(''); setShowAddColPopover(false);
    };

    // allDeletableCols is derived from TABLE_COLS later (after it's computed)

    const toggleColToDelete = (key) => {
        setColsToDelete(prev => {
            const next = new Set(prev);
            next.has(key) ? next.delete(key) : next.add(key);
            return next;
        });
    };

    const handleDeleteCols = () => {
        if (!activeCourse) return;

        // Separate into month keys to hide vs custom labels to remove
        const monthKeysToHide = [];
        const customLabelsToRemove = [];
        colsToDelete.forEach(key => {
            if (key.startsWith('custom::')) {
                customLabelsToRemove.push(key.replace('custom::', ''));
            } else {
                monthKeysToHide.push(key);
            }
        });

        // ⚡ Batch: compute final state and write once to avoid stale-closure overwrites
        const newHiddenCols = [
            ...(activeCourse.hiddenCols || []),
            ...monthKeysToHide.filter(k => !(activeCourse.hiddenCols || []).includes(k)),
        ];
        const newCustomCols = (activeCourse.customCols || []).filter(
            c => !customLabelsToRemove.includes(c)
        );
        updateCourse(activeCourse.id, { hiddenCols: newHiddenCols, customCols: newCustomCols });

        setColsToDelete(new Set()); setShowDelColPopover(false);
    };

    /* ── Row Edit ────────────────────────────────────────────── */
    const openEditStudent = (s) => {
        const init = { attendance: String(s.attendance ?? '') };
        (activeCourse?.customCols || []).forEach(col => {
            init[col] = s.custom_data?.[col] ?? '';
        });
        setEditForm(init);
        setEditingStudent(s);
    };

    const handleEditSave = async () => {
        if (!editingStudent) return;
        setEditSaving(true);
        const updates = {
            attendance: Number(editForm.attendance) || 0,
            custom_data: { ...(editingStudent.custom_data || {}) },
        };
        (activeCourse?.customCols || []).forEach(col => {
            updates.custom_data[col] = editForm[col] ?? '';
        });
        if (updateStudent) {
            await updateStudent(editingStudent.id, updates);
        } else {
            // Fallback: direct Supabase update
            await supabase.from('student_records').update(updates).eq('id', editingStudent.id);
        }
        setEditSaving(false);
        setEditingStudent(null);
    };

    /* ── Row Remove (unenroll only) ──────────────────────────── */
    const handleRemoveFromCourse = (studentId) => {
        if (!activeCourse) return;
        if (!window.confirm('Remove this student from the course?')) return;
        removeStudentFromCourse(activeCourse.id, studentId);
    };

    // Table column definitions — same normalization logic as semester table:
    // 1. Auto-detect month cols with data > 0 among enrolled students
    // 2. Map extra (custom) col labels → month key if they match a month name
    // 3. Unmatched custom labels become true custom cols (CustomCell)
    // Each column carries a deleteKey so allDeletableCols can be derived from TABLE_COLS.
    const hiddenSet = new Set(activeCourse?.hiddenCols || []);

    const TABLE_COLS = useMemo(() => {
        // Step 1: auto-detected month keys where any enrolled student has data
        const autoKeys = new Set(
            ALL_MONTH_COLS
                .filter(col => courseStudents.some(s => Number(s[col.key]) > 0))
                .map(col => col.key)
        );

        // Step 2: map custom labels to column objects
        const extraObjs = (activeCourse?.customCols || []).map(label => {
            const q = normalise(label);
            const match = ALL_MONTH_COLS.find(c =>
                normalise(c.label) === q ||
                normalise(c.label).startsWith(q) ||
                normalise(c.key).startsWith(q)
            );
            if (match) autoKeys.delete(match.key); // don't duplicate
            // deleteKey for custom cols always uses 'custom::' prefix
            return { key: match?.key ?? null, label, isMonth: !!match, deleteKey: `custom::${label}` };
        });

        // Step 3: build final list = visible auto months + extra cols
        const autoCols = ALL_MONTH_COLS
            .filter(c => autoKeys.has(c.key) && !hiddenSet.has(c.key))
            .map(c => ({ key: c.key, label: c.label, isMonth: true, deleteKey: c.key }));

        // Filter out hidden custom cols from extra
        const extraFiltered = extraObjs.filter(c => !hiddenSet.has(`custom::${c.label}`));

        return [...autoCols, ...extraFiltered];
    }, [courseStudents, activeCourse?.customCols, hiddenSet]);

    // Derive deletable cols directly from what is visible in the table
    const allDeletableCols = TABLE_COLS.map(c => ({
        key: c.deleteKey,
        label: c.label,
        isMonth: c.isMonth && !c.deleteKey?.startsWith('custom::'),
    }));

    return (
        <DashboardLayout>
            {/* Page header */}
            <div className="mb-6">
                <h1 className="text-2xl font-bold text-gray-900">Courses</h1>
                <p className="text-sm text-gray-400 mt-0.5">Manage your courses and enrolled students</p>
            </div>

            {/* My Courses header + Add Course */}
            <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-1.5 text-base font-bold text-gray-900">
                    <BookOpen className="w-5 h-5" /> My Courses
                </div>
                <button
                    onClick={() => { setShowAddCourse(true); setEditCourse(null); setCourseForm({ name: '', description: '' }); }}
                    className="flex items-center gap-2 px-4 py-2 bg-[#1a2b4b] text-white rounded-lg text-sm font-medium hover:bg-[#243557]"
                >
                    <Plus className="w-4 h-4" /> Add Course
                </button>
            </div>

            {courses.length === 0 ? (
                <div className="bg-white rounded-2xl border border-gray-200 py-16 text-center text-gray-400">
                    <BookOpen className="w-12 h-12 mx-auto mb-3 opacity-30" />
                    <p className="font-medium">No courses yet</p>
                    <p className="text-sm mt-1">Click "Add Course" to create your first course</p>
                </div>
            ) : (
                <>
                    {/* Course pill tabs */}
                    <div className="flex gap-2 flex-wrap mb-5">
                        {courses.map(c => (
                            <button key={c.id} onClick={() => setActiveCourseId(c.id)}
                                className={`px-4 py-1.5 rounded-full text-sm font-medium border transition-colors ${(activeCourseId === c.id) || (!activeCourseId && c.id === courses[0].id)
                                    ? 'bg-[#1a2b4b] text-white border-[#1a2b4b]'
                                    : 'border-gray-300 text-gray-600 hover:border-gray-400'
                                    }`}
                            >
                                {c.name} ({students.filter(s => c.studentIds.includes(s.id)).length})
                            </button>
                        ))}
                    </div>

                    {activeCourse && (
                        <div className="bg-white rounded-2xl border border-gray-200 p-5">
                            {/* Course meta row */}
                            <div className="flex items-start justify-between mb-4">
                                <div>
                                    <p className="text-sm text-gray-500">{activeCourse.description || 'No description'}</p>
                                    <p className="text-xs text-gray-400 mt-1 flex items-center gap-1">
                                        <Users className="w-3.5 h-3.5" /> {courseStudents.length} students enrolled
                                    </p>
                                </div>
                                <div className="flex gap-2">
                                    <button onClick={() => openEditCourse(activeCourse)}
                                        className="flex items-center gap-1 px-3 py-1.5 border border-gray-200 rounded-lg text-sm hover:bg-gray-50">
                                        <Pencil className="w-3.5 h-3.5" /> Edit
                                    </button>
                                    <button
                                        onClick={() => { if (window.confirm('Delete this course?')) { deleteCourse(activeCourse.id); setActiveCourseId(null); } }}
                                        className="flex items-center gap-1 px-3 py-1.5 border border-red-200 text-red-500 rounded-lg text-sm hover:bg-red-50">
                                        <Trash2 className="w-3.5 h-3.5" /> Delete
                                    </button>
                                </div>
                            </div>

                            {/* Table controls */}
                            <div className="flex justify-end gap-2 mb-3">

                                {/* Delete Column — multi-select, covers ALL visible columns */}
                                <div className="relative">
                                    <button
                                        onClick={() => { setShowDelColPopover(s => !s); setShowAddColPopover(false); setColsToDelete(new Set()); }}
                                        disabled={allDeletableCols.length === 0}
                                        title={allDeletableCols.length === 0 ? 'No columns to delete' : 'Delete columns'}
                                        className="flex items-center gap-1.5 px-3 py-1.5 border border-red-200 text-red-500 rounded-lg text-sm hover:bg-red-50 disabled:opacity-40 disabled:cursor-not-allowed"
                                    >
                                        <Trash2 className="w-3.5 h-3.5" /> Delete Column
                                    </button>
                                    {showDelColPopover && allDeletableCols.length > 0 && (
                                        <div className="absolute right-0 top-9 bg-white border border-gray-200 rounded-xl shadow-lg p-4 z-20 w-64">
                                            <p className="text-xs font-semibold text-gray-700 mb-1">Select columns to remove</p>
                                            <p className="text-[10px] text-gray-400 mb-3">Removes selected columns from this course's table only.</p>
                                            <div className="space-y-1.5 max-h-48 overflow-y-auto mb-3">
                                                {allDeletableCols.map(col => (
                                                    <label key={col.key} className="flex items-center gap-2.5 px-2 py-1.5 rounded-lg hover:bg-gray-50 cursor-pointer">
                                                        <input
                                                            type="checkbox"
                                                            checked={colsToDelete.has(col.key)}
                                                            onChange={() => toggleColToDelete(col.key)}
                                                            className="w-4 h-4 accent-red-500"
                                                        />
                                                        <span className="text-sm text-gray-800 truncate">{col.label}</span>
                                                        {!col.isMonth && (
                                                            <span className="ml-auto text-[10px] text-blue-400 font-medium">custom</span>
                                                        )}
                                                    </label>
                                                ))}
                                            </div>
                                            <div className="flex gap-2">
                                                <button
                                                    onClick={() => { setShowDelColPopover(false); setColsToDelete(new Set()); }}
                                                    className="flex-1 py-1.5 border border-gray-200 rounded-lg text-xs text-gray-600 hover:bg-gray-50"
                                                >Cancel</button>
                                                <button
                                                    onClick={handleDeleteCols}
                                                    disabled={colsToDelete.size === 0}
                                                    className="flex-1 py-1.5 bg-red-500 text-white rounded-lg text-xs font-semibold hover:bg-red-600 disabled:opacity-40"
                                                >Delete ({colsToDelete.size})</button>
                                            </div>
                                        </div>
                                    )}
                                </div>

                                {/* Add Column */}
                                <div className="relative">
                                    <button
                                        onClick={() => { setShowAddColPopover(s => !s); setShowDelColPopover(false); }}
                                        className="flex items-center gap-1.5 px-3 py-1.5 border border-gray-200 rounded-lg text-sm hover:bg-gray-50"
                                    >
                                        <LayoutList className="w-3.5 h-3.5" /> Add Column
                                    </button>
                                    {showAddColPopover && (
                                        <div className="absolute right-0 top-9 bg-white border border-gray-200 rounded-xl shadow-lg p-4 z-10 w-52">
                                            <p className="text-xs font-semibold text-gray-600 mb-2">Column Name</p>
                                            <input
                                                value={newColName}
                                                onChange={e => setNewColName(e.target.value)}
                                                onKeyDown={e => e.key === 'Enter' && handleAddCol()}
                                                placeholder="e.g., Semester Marks"
                                                className={`${inputCls} mb-2`}
                                                autoFocus
                                            />
                                            <button onClick={handleAddCol} disabled={!newColName}
                                                className="w-full py-1.5 bg-[#1a2b4b] text-white rounded-lg text-xs font-medium disabled:opacity-40">
                                                Add Column
                                            </button>
                                        </div>
                                    )}
                                </div>

                                {/* Manage Students */}
                                <button onClick={() => setShowManage(true)}
                                    className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 text-white rounded-lg text-sm hover:bg-blue-700">
                                    <Users className="w-3.5 h-3.5" /> Manage Students
                                </button>
                            </div>

                            {/* Student table */}
                            <div className="overflow-x-auto">
                                <table className="w-full text-sm min-w-[700px]">
                                    <thead>
                                        <tr className="border-b">
                                            <th className="px-4 py-2.5 text-left text-xs font-semibold text-gray-700">Student ID</th>
                                            <th className="px-4 py-2.5 text-left text-xs font-semibold text-gray-700">Name</th>
                                            <th className="px-4 py-2.5 text-left text-xs font-semibold text-gray-700">Email</th>
                                            <th className="px-4 py-2.5 text-left text-xs font-semibold text-gray-700">Contact</th>
                                            <th className="px-4 py-2.5 text-left text-xs font-semibold text-gray-700">Attendance</th>
                                            {TABLE_COLS.map(c => (
                                                <th key={c.key ?? c.label} className={`px-4 py-2.5 text-left text-xs font-semibold whitespace-nowrap ${c.key ? 'text-gray-700' : 'text-blue-600'}`}>
                                                    {c.label}
                                                </th>
                                            ))}
                                            <th className="px-4 py-2.5 text-right text-xs font-semibold text-gray-700">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-gray-100">
                                        {courseStudents.length === 0 ? (
                                            <tr>
                                                <td colSpan={6 + TABLE_COLS.length} className="py-10 text-center text-gray-400 text-sm">
                                                    No students enrolled. Use "Manage Students" to add.
                                                </td>
                                            </tr>
                                        ) : courseStudents.map(s => (
                                            <tr key={s.id} className="hover:bg-gray-50">
                                                <td className="px-4 py-3 text-gray-500">{s.student_id || '—'}</td>
                                                <td className="px-4 py-3 font-medium text-gray-900">{s.name}</td>
                                                <td className="px-4 py-3 text-gray-500 text-xs">{s.email || '—'}</td>
                                                <td className="px-4 py-3 text-gray-500">{s.contact || '—'}</td>
                                                <td className="px-4 py-3"><AttBar value={s.attendance} /></td>
                                                {TABLE_COLS.map(c => (
                                                    <td key={c.key ?? c.label} className="px-4 py-3">
                                                        {c.key
                                                            ? <AttBar value={s[c.key]} />
                                                            : <CustomCell
                                                                student={s}
                                                                colLabel={c.label}
                                                                onSave={async (newVal) => {
                                                                    const merged = { ...(s.custom_data || {}), [c.label]: newVal };
                                                                    if (updateStudent) await updateStudent(s.id, { custom_data: merged });
                                                                    else await supabase.from('student_records').update({ custom_data: merged }).eq('id', s.id);
                                                                }}
                                                            />
                                                        }
                                                    </td>
                                                ))}
                                                {/* Actions */}
                                                <td className="px-4 py-3">
                                                    <div className="flex items-center justify-end gap-3">
                                                        <button
                                                            onClick={() => openEditStudent(s)}
                                                            className="flex items-center gap-1 text-xs font-medium text-blue-600 hover:text-blue-800"
                                                        >
                                                            <Pencil className="w-3 h-3" /> Edit
                                                        </button>
                                                        <button
                                                            onClick={() => handleRemoveFromCourse(s.id)}
                                                            className="flex items-center gap-1 text-xs font-medium text-red-500 hover:text-red-700"
                                                        >
                                                            <Trash2 className="w-3 h-3" /> Remove
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    )}
                </>
            )}

            {/* ── Add / Edit Course Modal ─────────────────────── */}
            {showAddCourse && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
                    <div className="bg-white rounded-2xl shadow-xl w-full max-w-sm p-6">
                        <div className="flex justify-between items-center mb-4">
                            <h3 className="font-semibold text-gray-900">{editCourse ? 'Edit Course' : 'Add Course'}</h3>
                            <button onClick={() => { setShowAddCourse(false); setEditCourse(null); }} className="text-gray-400">
                                <X className="w-5 h-5" />
                            </button>
                        </div>
                        <div className="space-y-3">
                            <div>
                                <label className="text-xs font-medium text-gray-600 block mb-1">Course Name *</label>
                                <input value={courseForm.name} onChange={e => setCourseForm(p => ({ ...p, name: e.target.value }))}
                                    className={inputCls} placeholder="e.g., Data Structures" />
                            </div>
                            <div>
                                <label className="text-xs font-medium text-gray-600 block mb-1">Description</label>
                                <input value={courseForm.description} onChange={e => setCourseForm(p => ({ ...p, description: e.target.value }))}
                                    className={inputCls} placeholder="e.g., 3rd sem subject" />
                            </div>
                        </div>
                        <div className="flex gap-3 mt-5">
                            <button onClick={() => { setShowAddCourse(false); setEditCourse(null); }}
                                className="flex-1 py-2 border border-gray-200 rounded-lg text-sm">Cancel</button>
                            <button onClick={handleAddCourse} disabled={!courseForm.name}
                                className="flex-1 py-2 bg-[#1a2b4b] text-white rounded-lg text-sm font-medium disabled:opacity-50">
                                {editCourse ? 'Update' : 'Add Course'}
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* ── Edit Student Modal ──────────────────────────── */}
            {editingStudent && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
                    <div className="bg-white rounded-2xl shadow-xl w-full max-w-sm p-6">
                        <div className="flex justify-between items-center mb-4">
                            <div>
                                <h3 className="font-semibold text-gray-900">Edit Student Data</h3>
                                <p className="text-xs text-gray-400 mt-0.5">{editingStudent.name} • {activeCourse?.name}</p>
                            </div>
                            <button onClick={() => setEditingStudent(null)} className="text-gray-400">
                                <X className="w-5 h-5" />
                            </button>
                        </div>

                        <div className="space-y-3 max-h-64 overflow-y-auto pr-1">
                            <div>
                                <label className="text-xs font-medium text-gray-600 block mb-1">Attendance %</label>
                                <input
                                    type="number" min={0} max={100}
                                    value={editForm.attendance || ''}
                                    onChange={e => setEditForm(p => ({ ...p, attendance: e.target.value }))}
                                    placeholder="0"
                                    className={inputCls}
                                />
                            </div>
                            {(activeCourse?.customCols || []).map(col => (
                                <div key={col}>
                                    <label className="text-xs font-medium text-gray-600 block mb-1">{col}</label>
                                    <input
                                        value={editForm[col] || ''}
                                        onChange={e => setEditForm(p => ({ ...p, [col]: e.target.value }))}
                                        placeholder="—"
                                        className={inputCls}
                                    />
                                </div>
                            ))}
                        </div>

                        <div className="flex gap-3 mt-5">
                            <button onClick={() => setEditingStudent(null)}
                                className="flex-1 py-2 border border-gray-200 rounded-lg text-sm">Cancel</button>
                            <button
                                onClick={handleEditSave}
                                disabled={editSaving}
                                className="flex-1 py-2 bg-[#1a2b4b] text-white rounded-lg text-sm font-medium disabled:opacity-50"
                            >
                                {editSaving ? 'Saving…' : 'Save Changes'}
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* ── Manage Students Modal ───────────────────────── */}
            {showManage && activeCourse && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
                    <div className="bg-white rounded-2xl shadow-xl w-full max-w-md p-6">
                        <div className="flex justify-between items-center mb-4">
                            <h3 className="font-semibold text-gray-900">Manage Students — {activeCourse.name}</h3>
                            <button onClick={() => setShowManage(false)} className="text-gray-400"><X className="w-5 h-5" /></button>
                        </div>
                        <div className="max-h-80 overflow-y-auto space-y-2">
                            {students.length === 0
                                ? <p className="text-gray-400 text-sm text-center py-8">No students yet. Add students first.</p>
                                : students.map(s => {
                                    const enrolled = activeCourse.studentIds.includes(s.id);
                                    return (
                                        <div key={s.id} className="flex items-center justify-between px-3 py-2 rounded-lg hover:bg-gray-50">
                                            <div>
                                                <p className="text-sm font-medium text-gray-900">{s.name}</p>
                                                <p className="text-xs text-gray-400">Year {s.year} · Sem {s.semester}</p>
                                            </div>
                                            <button
                                                onClick={() => enrolled ? removeStudentFromCourse(activeCourse.id, s.id) : addStudentToCourse(activeCourse.id, s.id)}
                                                className={`px-3 py-1 rounded-lg text-xs font-medium ${enrolled ? 'bg-red-100 text-red-600' : 'bg-blue-100 text-blue-600'}`}
                                            >
                                                {enrolled ? 'Remove' : 'Add'}
                                            </button>
                                        </div>
                                    );
                                })
                            }
                        </div>
                        <button onClick={() => setShowManage(false)}
                            className="w-full mt-4 py-2 bg-[#1a2b4b] text-white rounded-xl text-sm font-medium">
                            Done
                        </button>
                    </div>
                </div>
            )}
        </DashboardLayout>
    );
}
