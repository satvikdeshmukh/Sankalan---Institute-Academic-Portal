import React, { useState, useRef, useEffect, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext.jsx';
import { useStudents } from '../../hooks/useStudents.js';
import { useCourses } from '../../hooks/useCourses.js';
import { useCustomCols } from '../../hooks/useCustomCols.js';
import DashboardLayout from '../../components/layout/DashboardLayout.jsx';
import { Plus, Trash2, Download, Upload, X, LayoutList, BookOpen, Users, Pencil } from 'lucide-react';
import * as XLSX from 'xlsx';

// Default visible monthly columns
const DEFAULT_MONTH_COLS = [
    { key: 'jan_att', label: 'January Att.' },
    { key: 'feb_att', label: 'February Att.' },
    { key: 'mar_att', label: 'March Att.' },
];

// All possible month columns
const ALL_MONTH_COLS = [
    { key: 'jan_att', label: 'January Att.' }, { key: 'feb_att', label: 'February Att.' },
    { key: 'mar_att', label: 'March Att.' }, { key: 'apr_att', label: 'April Att.' },
    { key: 'may_att', label: 'May Att.' }, { key: 'jun_att', label: 'June Att.' },
    { key: 'jul_att', label: 'July Att.' }, { key: 'aug_att', label: 'August Att.' },
    { key: 'sep_att', label: 'September Att.' }, { key: 'oct_att', label: 'October Att.' },
    { key: 'nov_att', label: 'November Att.' }, { key: 'dec_att', label: 'December Att.' },
];

function AttBar({ value }) {
    const pct = Math.min(100, Math.max(0, Number(value) || 0));
    const color = pct >= 75 ? '#16a34a' : pct >= 50 ? '#f59e0b' : '#ef4444';
    return (
        <div className="flex items-center gap-2 min-w-[80px]">
            <div className="flex-1 h-1.5 bg-gray-200 rounded-full overflow-hidden">
                <div style={{ width: `${pct}%`, backgroundColor: color }} className="h-full rounded-full" />
            </div>
            <span className="text-xs text-gray-600 w-8 text-right">{pct}%</span>
        </div>
    );
}

// Inline editable cell for custom (non-month) columns
// Reads/writes to student.custom_data[colLabel] via Supabase
function CustomCell({ student, colLabel, onSave }) {
    const initial = student.custom_data?.[colLabel] ?? '';
    const [val, setVal] = useState(initial);
    const [saving, setSaving] = useState(false);

    const commit = async () => {
        if (val === (student.custom_data?.[colLabel] ?? '')) return; // no change
        setSaving(true);
        await onSave(val);
        setSaving(false);
    };

    return (
        <input
            value={val}
            onChange={e => setVal(e.target.value)}
            onBlur={commit}
            onKeyDown={e => e.key === 'Enter' && e.target.blur()}
            disabled={saving}
            placeholder="—"
            className={`w-24 text-xs border rounded px-2 py-1 focus:outline-none focus:ring-1 focus:ring-blue-400 ${saving ? 'opacity-50 bg-gray-50' : 'border-gray-200 bg-white hover:border-blue-300'
                }`}
        />
    );
}

const MONTH_ATT_KEYS = [
    'jan_att', 'feb_att', 'mar_att', 'apr_att', 'may_att', 'jun_att',
    'jul_att', 'aug_att', 'sep_att', 'oct_att', 'nov_att', 'dec_att',
];

// Computes average from monthly fields; falls back to stored attendance if no monthly data
function calcAvgAtt(student) {
    const vals = MONTH_ATT_KEYS
        .map(k => Number(student[k]))
        .filter(v => !isNaN(v) && v > 0);
    if (vals.length === 0) return Number(student.attendance) || 0;
    return Math.round(vals.reduce((a, b) => a + b, 0) / vals.length);
}

const YEAR_LABELS = ['1st Year', '2nd Year', '3rd Year', '4th Year'];
const YEAR_SEM = { 1: [1, 2], 2: [3, 4], 3: [5, 6], 4: [7, 8] };

const EMPTY_FORM = {
    student_id: '', name: '', email: '', contact: '', year: '', semester: '', attendance: '',
    jan_att: '', feb_att: '', mar_att: '', apr_att: '', may_att: '', jun_att: '',
    jul_att: '', aug_att: '', sep_att: '', oct_att: '', nov_att: '', dec_att: '',
};

/* ══ Courses Tab ════════════════════════════════════════════ */
function CoursesView({ students, userId, inputCls, updateStudent }) {
    const {
        courses, addCourse, updateCourse, deleteCourse,
        addStudentToCourse, removeStudentFromCourse,
        addCustomCol, removeCustomCol
    } = useCourses(userId);

    const [activeCourseId, setActiveCourseId] = useState(null);
    const [showAddCourse, setShowAddCourse] = useState(false);
    const [editCourse, setEditCourse] = useState(null);
    const [courseForm, setCourseForm] = useState({ name: '', description: '' });
    const [showManage, setShowManage] = useState(false);

    // Add Column
    const [showAddColPopover, setShowAddColPopover] = useState(false);
    const [newColName, setNewColName] = useState('');

    // Delete Column (multi-select)
    const [showDelColPopover, setShowDelColPopover] = useState(false);
    const [colsToDelete, setColsToDelete] = useState(new Set());

    // Edit row
    const [editingStudent, setEditingStudent] = useState(null); // student object
    const [editForm, setEditForm] = useState({});   // { colLabel: value }
    const [editSaving, setEditSaving] = useState(false);

    const activeCourse = courses.find(c => c.id === activeCourseId) || courses[0];

    const courseStudents = useMemo(() =>
        activeCourse ? students.filter(s => activeCourse.studentIds.includes(s.id)) : [],
        [activeCourse, students]);

    /* ─ Course CRUD ────────────────────── */
    const handleAddCourse = () => {
        if (!courseForm.name) return;
        if (editCourse) {
            updateCourse(editCourse.id, courseForm);
        } else {
            const c = addCourse(courseForm.name, courseForm.description);
            setActiveCourseId(c.id);
        }
        setCourseForm({ name: '', description: '' });
        setShowAddCourse(false); setEditCourse(null);
    };
    const openEditCourse = (c) => {
        setEditCourse(c); setCourseForm({ name: c.name, description: c.description });
        setShowAddCourse(true);
    };

    /* ─ Column helpers ─────────────────── */
    const handleAddCol = () => {
        if (newColName && activeCourse) addCustomCol(activeCourse.id, newColName);
        setNewColName(''); setShowAddColPopover(false);
    };

    const toggleColToDelete = (col) => {
        setColsToDelete(prev => {
            const next = new Set(prev);
            next.has(col) ? next.delete(col) : next.add(col);
            return next;
        });
    };
    const handleDeleteCols = () => {
        if (!activeCourse) return;
        colsToDelete.forEach(col => removeCustomCol(activeCourse.id, col));
        setColsToDelete(new Set()); setShowDelColPopover(false);
    };

    /* ─ Row Edit / Remove ─────────────── */
    const openEditStudent = (s) => {
        // Build initial form: attendance + each custom col value
        const init = { attendance: String(s.attendance ?? '') };
        (activeCourse?.customCols || []).forEach(col => {
            init[col] = s.custom_data?.[col] ?? '';
        });
        setEditForm(init);
        setEditingStudent(s);
    };

    const handleEditSave = async () => {
        if (!editingStudent) return;
        setEditSaving(true);
        const updates = {
            attendance: Number(editForm.attendance) || 0,
            custom_data: { ...(editingStudent.custom_data || {}) },
        };
        (activeCourse?.customCols || []).forEach(col => {
            updates.custom_data[col] = editForm[col] ?? '';
        });
        await updateStudent(editingStudent.id, updates);
        setEditSaving(false);
        setEditingStudent(null);
    };

    const handleRemoveFromCourse = (studentId) => {
        if (!activeCourse) return;
        if (!window.confirm('Remove this student from the course?')) return;
        removeStudentFromCourse(activeCourse.id, studentId);
    };

    /* ─ All col headers to show in table ──── */
    const TABLE_COLS = [
        { key: 'jan_att', label: 'January Att.' },
        { key: 'feb_att', label: 'February Att.' },
        { key: 'mar_att', label: 'March Att.' },
        ...(activeCourse?.customCols || []).map(c => ({ key: null, label: c })),
    ];

    return (
        <div>
            {/* Course list header */}
            <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-1.5 text-base font-bold text-gray-900">
                    <BookOpen className="w-5 h-5" /> Courses
                </div>
                <button
                    onClick={() => { setShowAddCourse(true); setEditCourse(null); setCourseForm({ name: '', description: '' }); }}
                    className="flex items-center gap-2 px-4 py-2 bg-[#1a2b4b] text-white rounded-lg text-sm font-medium hover:bg-[#243557]"
                >
                    <Plus className="w-4 h-4" /> Add Course
                </button>
            </div>

            {courses.length === 0 ? (
                <div className="bg-white rounded-2xl border border-gray-200 py-16 text-center text-gray-400">
                    <BookOpen className="w-12 h-12 mx-auto mb-3 opacity-30" />
                    <p>No courses yet. Click "Add Course" to get started.</p>
                </div>
            ) : (
                <>
                    {/* Course tabs */}
                    <div className="flex gap-2 flex-wrap mb-4">
                        {courses.map(c => (
                            <button key={c.id} onClick={() => setActiveCourseId(c.id)}
                                className={`px-4 py-1.5 rounded-full text-sm font-medium border transition-colors ${(activeCourseId === c.id || (!activeCourseId && c.id === courses[0].id))
                                        ? 'bg-[#1a2b4b] text-white border-[#1a2b4b]'
                                        : 'border-gray-300 text-gray-600'
                                    }`}
                            >
                                {c.name} ({students.filter(s => c.studentIds.includes(s.id)).length})
                            </button>
                        ))}
                    </div>

                    {activeCourse && (
                        <div className="bg-white rounded-2xl border border-gray-200 p-5">
                            {/* Course info row */}
                            <div className="flex items-start justify-between mb-3">
                                <div>
                                    <p className="text-sm text-gray-500">{activeCourse.description || 'No description'}</p>
                                    <p className="text-xs text-gray-400 mt-1 flex items-center gap-1">
                                        <Users className="w-3.5 h-3.5" /> {courseStudents.length} students enrolled
                                    </p>
                                </div>
                                <div className="flex gap-2">
                                    <button onClick={() => openEditCourse(activeCourse)}
                                        className="flex items-center gap-1 px-3 py-1.5 border border-gray-200 rounded-lg text-sm hover:bg-gray-50">
                                        <Pencil className="w-3.5 h-3.5" /> Edit
                                    </button>
                                    <button
                                        onClick={() => { if (window.confirm('Delete this course?')) deleteCourse(activeCourse.id); }}
                                        className="flex items-center gap-1 px-3 py-1.5 border border-red-200 text-red-500 rounded-lg text-sm hover:bg-red-50">
                                        <Trash2 className="w-3.5 h-3.5" /> Delete
                                    </button>
                                </div>
                            </div>

                            {/* Table controls */}
                            <div className="flex justify-end gap-2 mb-3">
                                {/* Delete Column (multi-select) */}
                                <div className="relative">
                                    <button
                                        onClick={() => { setShowDelColPopover(s => !s); setShowAddColPopover(false); setColsToDelete(new Set()); }}
                                        disabled={!activeCourse.customCols?.length}
                                        title={!activeCourse.customCols?.length ? 'No custom columns to delete' : 'Delete columns'}
                                        className="flex items-center gap-1.5 px-3 py-1.5 border border-red-200 text-red-500 rounded-lg text-sm hover:bg-red-50 disabled:opacity-40 disabled:cursor-not-allowed"
                                    >
                                        <Trash2 className="w-3.5 h-3.5" /> Delete Column
                                    </button>
                                    {showDelColPopover && activeCourse.customCols?.length > 0 && (
                                        <div className="absolute right-0 top-9 bg-white border border-gray-200 rounded-xl shadow-lg p-4 z-20 w-60">
                                            <p className="text-xs font-semibold text-gray-700 mb-1">Select columns to remove</p>
                                            <p className="text-[10px] text-gray-400 mb-3">Removes from this course's table only.</p>
                                            <div className="space-y-1.5 max-h-44 overflow-y-auto mb-3">
                                                {activeCourse.customCols.map(col => (
                                                    <label key={col} className="flex items-center gap-2.5 px-2 py-1.5 rounded-lg hover:bg-gray-50 cursor-pointer">
                                                        <input
                                                            type="checkbox"
                                                            checked={colsToDelete.has(col)}
                                                            onChange={() => toggleColToDelete(col)}
                                                            className="w-4 h-4 accent-red-500"
                                                        />
                                                        <span className="text-sm text-gray-800 truncate">{col}</span>
                                                    </label>
                                                ))}
                                            </div>
                                            <div className="flex gap-2">
                                                <button
                                                    onClick={() => { setShowDelColPopover(false); setColsToDelete(new Set()); }}
                                                    className="flex-1 py-1.5 border border-gray-200 rounded-lg text-xs text-gray-600 hover:bg-gray-50"
                                                >Cancel</button>
                                                <button
                                                    onClick={handleDeleteCols}
                                                    disabled={colsToDelete.size === 0}
                                                    className="flex-1 py-1.5 bg-red-500 text-white rounded-lg text-xs font-semibold hover:bg-red-600 disabled:opacity-40"
                                                >Delete ({colsToDelete.size})</button>
                                            </div>
                                        </div>
                                    )}
                                </div>

                                {/* Add Column */}
                                <div className="relative">
                                    <button
                                        onClick={() => { setShowAddColPopover(s => !s); setShowDelColPopover(false); }}
                                        className="flex items-center gap-1.5 px-3 py-1.5 border border-gray-200 rounded-lg text-sm hover:bg-gray-50"
                                    >
                                        <LayoutList className="w-3.5 h-3.5" /> Add Column
                                    </button>
                                    {showAddColPopover && (
                                        <div className="absolute right-0 top-9 bg-white border border-gray-200 rounded-xl shadow-lg p-4 z-10 w-52">
                                            <p className="text-xs font-semibold text-gray-600 mb-2">Column Name</p>
                                            <input
                                                value={newColName}
                                                onChange={e => setNewColName(e.target.value)}
                                                onKeyDown={e => e.key === 'Enter' && handleAddCol()}
                                                placeholder="e.g., Semester Marks"
                                                className={`${inputCls} mb-2`}
                                                autoFocus
                                            />
                                            <button onClick={handleAddCol} disabled={!newColName}
                                                className="w-full py-1.5 bg-[#1a2b4b] text-white rounded-lg text-xs font-medium disabled:opacity-40"
                                            >Add Column</button>
                                        </div>
                                    )}
                                </div>

                                {/* Manage Students */}
                                <button onClick={() => setShowManage(true)}
                                    className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 text-white rounded-lg text-sm hover:bg-blue-700">
                                    <Users className="w-3.5 h-3.5" /> Manage Students
                                </button>
                            </div>

                            {/* Table */}
                            <div className="overflow-x-auto">
                                <table className="w-full text-sm min-w-[600px]">
                                    <thead>
                                        <tr className="border-b">
                                            <th className="px-3 py-2.5 text-left text-xs font-semibold text-gray-700">Student ID</th>
                                            <th className="px-3 py-2.5 text-left text-xs font-semibold text-gray-700">Name</th>
                                            <th className="px-3 py-2.5 text-left text-xs font-semibold text-gray-700">Email</th>
                                            <th className="px-3 py-2.5 text-left text-xs font-semibold text-gray-700">Contact</th>
                                            <th className="px-3 py-2.5 text-left text-xs font-semibold text-gray-700">Attendance</th>
                                            {TABLE_COLS.slice(0, 3).map(c => (
                                                <th key={c.key ?? c.label} className="px-3 py-2.5 text-left text-xs font-semibold text-gray-700 whitespace-nowrap">{c.label}</th>
                                            ))}
                                            {activeCourse.customCols?.map(col => (
                                                <th key={col} className="px-3 py-2.5 text-left text-xs font-semibold text-blue-600">{col}</th>
                                            ))}
                                            <th className="px-3 py-2.5 text-right text-xs font-semibold text-gray-700">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-gray-100">
                                        {courseStudents.length === 0 ? (
                                            <tr>
                                                <td colSpan={9 + (activeCourse.customCols?.length || 0)} className="py-10 text-center text-gray-400 text-sm">
                                                    No students enrolled. Use "Manage Students" to add.
                                                </td>
                                            </tr>
                                        ) : courseStudents.map(s => (
                                            <tr key={s.id} className="hover:bg-gray-50">
                                                <td className="px-3 py-3 text-gray-500 text-xs">{s.student_id || '—'}</td>
                                                <td className="px-3 py-3 font-medium text-gray-900">{s.name}</td>
                                                <td className="px-3 py-3 text-gray-500 text-xs">{s.email || '—'}</td>
                                                <td className="px-3 py-3 text-gray-500 text-xs">{s.contact || '—'}</td>
                                                <td className="px-3 py-3"><AttBar value={s.attendance} /></td>
                                                {TABLE_COLS.slice(0, 3).map(c => (
                                                    <td key={c.key ?? c.label} className="px-3 py-3">
                                                        <AttBar value={s[c.key]} />
                                                    </td>
                                                ))}
                                                {activeCourse.customCols?.map(col => (
                                                    <td key={col} className="px-3 py-3 text-gray-600 text-xs">
                                                        {s.custom_data?.[col] ?? '—'}
                                                    </td>
                                                ))}
                                                {/* Actions: Edit + Remove */}
                                                <td className="px-3 py-3">
                                                    <div className="flex items-center justify-end gap-2">
                                                        <button
                                                            onClick={() => openEditStudent(s)}
                                                            className="flex items-center gap-1 text-xs font-medium text-blue-600 hover:text-blue-800"
                                                        >
                                                            <Pencil className="w-3 h-3" /> Edit
                                                        </button>
                                                        <button
                                                            onClick={() => handleRemoveFromCourse(s.id)}
                                                            className="flex items-center gap-1 text-xs font-medium text-red-500 hover:text-red-700"
                                                        >
                                                            <Trash2 className="w-3 h-3" /> Remove
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    )}
                </>
            )}

            {/* ── Add / Edit Course Modal ──────────────────────────── */}
            {showAddCourse && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
                    <div className="bg-white rounded-2xl shadow-xl w-full max-w-sm p-6">
                        <div className="flex justify-between items-center mb-4">
                            <h3 className="font-semibold text-gray-900">{editCourse ? 'Edit Course' : 'Add Course'}</h3>
                            <button onClick={() => { setShowAddCourse(false); setEditCourse(null); }} className="text-gray-400">
                                <X className="w-5 h-5" />
                            </button>
                        </div>
                        <div className="space-y-3">
                            <div>
                                <label className="text-xs font-medium text-gray-600 block mb-1">Course Name *</label>
                                <input value={courseForm.name} onChange={e => setCourseForm(p => ({ ...p, name: e.target.value }))} className={inputCls} placeholder="e.g., Data Structures" />
                            </div>
                            <div>
                                <label className="text-xs font-medium text-gray-600 block mb-1">Description</label>
                                <input value={courseForm.description} onChange={e => setCourseForm(p => ({ ...p, description: e.target.value }))} className={inputCls} placeholder="e.g., 3rd sem subject" />
                            </div>
                        </div>
                        <div className="flex gap-3 mt-5">
                            <button onClick={() => { setShowAddCourse(false); setEditCourse(null); }} className="flex-1 py-2 border border-gray-200 rounded-lg text-sm">Cancel</button>
                            <button onClick={handleAddCourse} disabled={!courseForm.name} className="flex-1 py-2 bg-[#1a2b4b] text-white rounded-lg text-sm font-medium disabled:opacity-50">
                                {editCourse ? 'Update' : 'Add Course'}
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* ── Edit Student Modal ─────────────────────────────── */}
            {editingStudent && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
                    <div className="bg-white rounded-2xl shadow-xl w-full max-w-sm p-6">
                        <div className="flex justify-between items-center mb-4">
                            <div>
                                <h3 className="font-semibold text-gray-900">Edit Student Data</h3>
                                <p className="text-xs text-gray-400 mt-0.5">{editingStudent.name} • {activeCourse?.name}</p>
                            </div>
                            <button onClick={() => setEditingStudent(null)} className="text-gray-400"><X className="w-5 h-5" /></button>
                        </div>

                        <div className="space-y-3 max-h-64 overflow-y-auto pr-1">
                            {/* Attendance */}
                            <div>
                                <label className="text-xs font-medium text-gray-600 block mb-1">Attendance %</label>
                                <input
                                    type="number" min={0} max={100}
                                    value={editForm.attendance || ''}
                                    onChange={e => setEditForm(p => ({ ...p, attendance: e.target.value }))}
                                    placeholder="0"
                                    className={inputCls}
                                />
                            </div>
                            {/* Custom columns */}
                            {(activeCourse?.customCols || []).map(col => (
                                <div key={col}>
                                    <label className="text-xs font-medium text-gray-600 block mb-1">{col}</label>
                                    <input
                                        value={editForm[col] || ''}
                                        onChange={e => setEditForm(p => ({ ...p, [col]: e.target.value }))}
                                        placeholder="—"
                                        className={inputCls}
                                    />
                                </div>
                            ))}
                        </div>

                        <div className="flex gap-3 mt-5">
                            <button onClick={() => setEditingStudent(null)} className="flex-1 py-2 border border-gray-200 rounded-lg text-sm">Cancel</button>
                            <button
                                onClick={handleEditSave}
                                disabled={editSaving}
                                className="flex-1 py-2 bg-[#1a2b4b] text-white rounded-lg text-sm font-medium disabled:opacity-50"
                            >
                                {editSaving ? 'Saving…' : 'Save Changes'}
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* ── Manage Students Modal ────────────────────────── */}
            {showManage && activeCourse && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
                    <div className="bg-white rounded-2xl shadow-xl w-full max-w-md p-6">
                        <div className="flex justify-between items-center mb-4">
                            <h3 className="font-semibold text-gray-900">Manage Students — {activeCourse.name}</h3>
                            <button onClick={() => setShowManage(false)} className="text-gray-400"><X className="w-5 h-5" /></button>
                        </div>
                        <div className="max-h-80 overflow-y-auto space-y-2">
                            {students.length === 0
                                ? <p className="text-gray-400 text-sm text-center py-8">No students yet. Add students first.</p>
                                : students.map(s => {
                                    const enrolled = activeCourse.studentIds.includes(s.id);
                                    return (
                                        <div key={s.id} className="flex items-center justify-between px-3 py-2 rounded-lg hover:bg-gray-50">
                                            <div>
                                                <p className="text-sm font-medium text-gray-900">{s.name}</p>
                                                <p className="text-xs text-gray-400">Year {s.year} · Sem {s.semester}</p>
                                            </div>
                                            <button
                                                onClick={() => enrolled ? removeStudentFromCourse(activeCourse.id, s.id) : addStudentToCourse(activeCourse.id, s.id)}
                                                className={`px-3 py-1 rounded-lg text-xs font-medium ${enrolled ? 'bg-red-100 text-red-600' : 'bg-blue-100 text-blue-600'}`}
                                            >
                                                {enrolled ? 'Remove' : 'Add'}
                                            </button>
                                        </div>
                                    );
                                })}
                        </div>
                        <button onClick={() => setShowManage(false)} className="w-full mt-4 py-2 bg-[#1a2b4b] text-white rounded-xl text-sm font-medium">Done</button>
                    </div>
                </div>
            )}
        </div>
    );
}


export default function TeacherStudents() {
    const [searchParams, setSearchParams] = useSearchParams();
    const { user, departmentId } = useAuth();
    const { students, loading, addStudent, updateStudent, deleteStudent, importStudents, refetch } = useStudents(user?.id, departmentId);

    // Tab state
    const [viewTab, setViewTab] = useState('semesters'); // 'semesters' | 'courses'
    const [selectedYear, setSelectedYear] = useState(Number(searchParams.get('year')) || 1);
    const [selectedSem, setSelectedSem] = useState(1);

    // Custom columns scoped to current year + semester (Supabase-persisted)
    const { cols: extraCols, addCol, removeCol } = useCustomCols(user?.id, selectedYear, selectedSem);

    // Extra columns UI state
    const [showAddCol, setShowAddCol] = useState(false);
    const [newColName, setNewColName] = useState('');
    const [showDeleteCol, setShowDeleteCol] = useState(false);
    const [colsToDelete, setColsToDelete] = useState(new Set()); // set of col labels

    // Modal state
    const [showModal, setShowModal] = useState(false);
    const [editingId, setEditingId] = useState(null);
    const [form, setForm] = useState(EMPTY_FORM);
    const [saving, setSaving] = useState(false);

        // ── Import Preview State ─────────────────────────────────────
const [showImportPreview, setShowImportPreview] = useState(false);
const [previewRows, setPreviewRows] = useState([]);
const [parsedImportData, setParsedImportData] = useState([]);
const [importing, setImporting] = useState(false);

// ── Toast State ─────────────────────────────
const [toast, setToast] = useState(null);

const showToast = (type, title, message) => {
    setToast({ type, title, message });

    // Auto close after 3 seconds
    setTimeout(() => {
        setToast(null);
    }, 3000);
};

    const fileRef = useRef();

    // Sync year + semester from URL params — run ONCE on mount only.
    // All navigation (tab clicks, handleSave) sets selectedYear/selectedSem directly.
    // Running this on every searchParams change caused a state race that wiped selectedSem.
    useEffect(() => {
        const y = Number(searchParams.get('year'));
        const s = Number(searchParams.get('sem'));

        const validYear = y >= 1 && y <= 4 ? y : 1;
        const validSem = s >= 1 && s <= 8 ? s : YEAR_SEM[validYear][0];

        setSelectedYear(validYear);
        setSelectedSem(validSem);
    }, [searchParams]); // ← intentionally empty: only read URL on first load

    // Filter students
    const yearStudents = useMemo(() =>
        students.filter(s => Number(s.year) === selectedYear),
        [students, selectedYear]);

    const displayStudents = useMemo(() => {
        if (!selectedSem) return yearStudents;
        return yearStudents.filter(s => Number(s.semester) === selectedSem);
    }, [yearStudents, selectedSem]);

    const sems = YEAR_SEM[selectedYear] || [1, 2];

    // Columns to display in the table:
    // 1. Auto-detect months where any student has data > 0 (always in Jan→Dec order)
    // 2. Append any manually added columns (teacher-typed labels)
    //    - If the label can be mapped to a known month key, use that key for data
    //    - Otherwise it's a custom header with no DB field (shows —)
    const monthCols = useMemo(() => {
        // Step 1: auto-detected month keys
        const autoKeys = new Set(
            ALL_MONTH_COLS
                .filter(col => displayStudents.some(s => Number(s[col.key]) > 0))
                .map(col => col.key)
        );

        // Step 2: map extra labels to column objects
        const normalise = str => str.toLowerCase().replace(/att\.?/g, '').replace(/[\s._-]+/g, '').trim();
        const extraObjs = extraCols.map(label => {
            const q = normalise(label);
            const match = ALL_MONTH_COLS.find(c =>
                normalise(c.label) === q ||
                normalise(c.label).startsWith(q) ||
                normalise(c.key).startsWith(q)
            );
            // If it maps to a month, mark that month as covered so it doesn't duplicate
            if (match) autoKeys.delete(match.key);
            return { key: match?.key ?? null, label };
        });

        // Step 3: build final list = auto months (in order) + extra user cols
        const autoCols = ALL_MONTH_COLS.filter(c => autoKeys.has(c.key));
        return [...autoCols, ...extraObjs];
    }, [displayStudents, extraCols]);

    // ── Add Column ──────────────────────────────────────────────
    const handleAddCol = async () => {
        const label = newColName.trim();
        if (!label) return;
        await addCol(label);          // saves to Supabase teacher_custom_cols
        setNewColName('');
        setShowAddCol(false);
    };

    // ── Delete Column (multi-select) ─────────────────────────────
    const toggleColToDelete = (label) => {
        setColsToDelete(prev => {
            const next = new Set(prev);
            next.has(label) ? next.delete(label) : next.add(label);
            return next;
        });
    };

    const handleDeleteCols = async () => {
        for (const label of colsToDelete) {
            await removeCol(label);   // deletes from Supabase teacher_custom_cols
        }
        setColsToDelete(new Set());
        setShowDeleteCol(false);
    };

    // ── CRUD ─────────────────────────────────────────────────────
    const openAdd = () => {
        setEditingId(null);
        // Pre-fill with currently selected semester, so new student appears in the active table
        const defaultSem = selectedSem || sems[0];
        setForm({ ...EMPTY_FORM, year: String(selectedYear), semester: String(defaultSem) });
        setShowModal(true);
    };
    const openEdit = (s) => {
        setEditingId(s.id);
        setForm({
            student_id: s.student_id || '', name: s.name || '', email: s.email || '',
            contact: s.contact || '', year: String(s.year) || '', semester: String(s.semester) || '',
            attendance: String(s.attendance || ''),
            jan_att: s.jan_att || '', feb_att: s.feb_att || '', mar_att: s.mar_att || '',
            apr_att: s.apr_att || '', may_att: s.may_att || '', jun_att: s.jun_att || '',
            jul_att: s.jul_att || '', aug_att: s.aug_att || '', sep_att: s.sep_att || '',
            oct_att: s.oct_att || '', nov_att: s.nov_att || '', dec_att: s.dec_att || '',
        });
        setShowModal(true);
    };
    const handleSave = async () => {
        if (!form.name) return;
        setSaving(true);
        const MONTH_KEYS = ['jan_att', 'feb_att', 'mar_att', 'apr_att', 'may_att', 'jun_att',
            'jul_att', 'aug_att', 'sep_att', 'oct_att', 'nov_att', 'dec_att'];
        const monthNums = {};
        MONTH_KEYS.forEach(k => { monthNums[k] = Number(form[k]) || 0; });
        const payload = {
            ...form,
            year: Number(form.year),
            semester: Number(form.semester),
            attendance: Number(form.attendance) || 0,
            ...monthNums,
        };
        console.log("IMPORTING:", payload);
        if (editingId) { await updateStudent(editingId, payload); }
        else { await addStudent(payload); }
        setSaving(false);
        setShowModal(false);

        const savedYear = payload.year;
        const savedSem = payload.semester;

        // Set state first so the filter is correct before refetch triggers a re-render
        setSelectedYear(savedYear);
        setSelectedSem(savedSem);

        // Fetch fresh data — selectedYear/selectedSem are already correct so filter works
        await refetch();

        // Update URL last so the useEffect doesn't race against the state above
        setSearchParams({ year: savedYear, sem: savedSem }, { replace: true });
    };
    const handleDelete = async (id) => {
        if (!window.confirm('Delete this student?')) return;
        await deleteStudent(id);
        await refetch();
    };

    // ── Excel Export ─────────────────────────────────────────────
    const handleExport = () => {
        const rows = displayStudents.map(s => ({
            'Student ID': s.student_id || '', Name: s.name, Email: s.email || '',
            Contact: s.contact || '', Year: s.year, Semester: s.semester,
            'Attendance %': s.attendance || 0,
            ...Object.fromEntries(ALL_MONTH_COLS.map(c => [c.label, s[c.key] || 0])),
        }));
        const ws = XLSX.utils.json_to_sheet(rows);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, 'Students');
        XLSX.writeFile(wb, `students_year${selectedYear}.xlsx`);
    };

    // ── Excel Import ─────────────────────────────────────────────
    // const handleImport = (e) => {
    //     const file = e.target.files?.[0]; if (!file) return;
    //     const reader = new FileReader();
    //     reader.onload = async (ev) => {
    //         const wb = XLSX.read(ev.target.result, { type: 'binary' });
    //         const raw = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]]);
    //         if (!raw.length) return;

    //         // Fuzzy month matching helper
    //         const norm = str => str.toLowerCase().replace(/att\.?/g, '').replace(/[\s._-]+/g, '').trim();
    //         const monthKeyByNorm = {};
    //         ALL_MONTH_COLS.forEach(c => {
    //             monthKeyByNorm[norm(c.label)] = c.key;
    //             monthKeyByNorm[norm(c.key)] = c.key;
    //         });

    //         // All headers that are standard DB fields (not custom)
    //         const STANDARD = new Set([
    //             'student id', 'student_id', 'name', 'email', 'contact',
    //             'year', 'semester', 'attendance %', 'attendance',
    //             ...ALL_MONTH_COLS.map(c => c.label.toLowerCase()),
    //             ...ALL_MONTH_COLS.map(c => c.key.toLowerCase()),
    //         ]);

    //         const allHeaders = Object.keys(raw[0] || {});

    //         // Custom = not a standard field and not a known month
    //         const customHeaders = allHeaders.filter(h =>
    //             !STANDARD.has(h.toLowerCase()) && !monthKeyByNorm[norm(h)]
    //         );

    //         // Register new custom column names for this semester in Supabase
    //         for (const h of customHeaders) await addCol(h);

    //         const toInsert = [];

    //         for (const r of raw) {
    //             const monthNums = {};
    //             allHeaders.forEach(h => {
    //                 const key = monthKeyByNorm[norm(h)];
    //                 if (key) monthNums[key] = Number(r[h]) || 0;
    //             });
    //             const custom_data = {};
    //             customHeaders.forEach(h => {
    //                 if (r[h] !== undefined && r[h] !== '') custom_data[h] = String(r[h]);
    //             });
    //             const payload = {
    //                 student_id: String(r['Student ID'] ?? r['student_id'] ?? ''),
    //                 name: String(r['Name'] ?? r['name'] ?? ''),
    //                 email: String(r['Email'] ?? r['email'] ?? ''),
    //                 contact: String(r['Contact'] ?? r['contact'] ?? ''),
    //                 year: selectedYear,
    //                 semester: selectedSem,
    //                 attendance: Number(r['Attendance %'] ?? r['attendance'] ?? 0),
    //                 ...monthNums,
    //                 custom_data,
    //             };

    //             // Match against existing students in this semester by student_id or name
    //             const existing = displayStudents.find(s =>
    //                 (payload.student_id && String(s.student_id) === payload.student_id) ||
    //                 (payload.name && s.name?.toLowerCase() === payload.name.toLowerCase())
    //             );

    //             if (existing) {
    //                 // Deep-merge custom_data so pre-existing custom values aren't wiped
    //                 const merged_custom = { ...(existing.custom_data || {}), ...custom_data };
    //                 await updateStudent(existing.id, { ...payload, custom_data: merged_custom });
    //             } else {
    //                 toInsert.push(payload);
    //             }
    //         }

    //         if (toInsert.length) await importStudents(toInsert);
    //         await refetch();
    //     };
    //     reader.readAsBinaryString(file);
    //     e.target.value = '';
    // };

    const handleImport = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();

    reader.onload = (ev) => {
        try {
            const wb = XLSX.read(ev.target.result, { type: 'binary' });
            const raw = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]]);

            if (!raw.length) {
                showToast('warning', 'Empty File', 'The Excel file is empty.');
                return;
            }

            setPreviewRows(raw.slice(0, 10));  // preview first 10
            setParsedImportData(raw);
            setShowImportPreview(true);

        } catch (err) {
            console.error(err);
            showToast('error', 'Read Error', 'Failed to read the Excel file. Please check the format.');
        }
    };

    reader.readAsBinaryString(file);
    e.target.value = '';
};

const confirmImport = async () => {
    try {
        setImporting(true);

        const raw = parsedImportData;
        if (!raw.length) {
            showToast('warning', 'No Data', 'No data found to import.');
            return;
        }

        const norm = str =>
            String(str || '')
                .toLowerCase()
                .replace(/att\.?/g, '')
                .replace(/[\s._-]+/g, '')
                .trim();

        const monthKeyByNorm = {};
        ALL_MONTH_COLS.forEach(c => {
            monthKeyByNorm[norm(c.label)] = c.key;
            monthKeyByNorm[norm(c.key)] = c.key;
        });

        const allHeaders = Object.keys(raw[0] || {});

        const STANDARD = new Set([
            'student id', 'student_id', 'name', 'email',
            'contact', 'year', 'semester',
            'attendance %', 'attendance'
        ]);

        const customHeaders = allHeaders.filter(h =>
            !STANDARD.has(h.toLowerCase()) && !monthKeyByNorm[norm(h)]
        );

        // Register custom columns
        for (const h of customHeaders) {
            await addCol(h);
        }

        let inserted = 0;
        let updated = 0;

        for (const r of raw) {

            const monthNums = {};
            allHeaders.forEach(h => {
                const key = monthKeyByNorm[norm(h)];
                if (key) monthNums[key] = Number(r[h]) || 0;
            });

            const custom_data = {};
            customHeaders.forEach(h => {
                if (r[h] !== undefined && r[h] !== '')
                    custom_data[h] = String(r[h]);
            });

            // 🔥 FIX: Read year & semester FROM EXCEL if present
            const excelYear = Number(r['Year'] ?? r['year']);
            const excelSem = Number(r['Semester'] ?? r['semester']);

            const finalYear =
                excelYear >= 1 && excelYear <= 4
                    ? excelYear
                    : selectedYear;

            const finalSem =
                excelSem >= 1 && excelSem <= 8
                    ? excelSem
                    : selectedSem;

            const payload = {
                student_id: r['Student ID'] != null? String(r['Student ID']): r['student_id'] != null? String(r['student_id']): null,
                name: r['Name'] ?? r['name'] ?? '',
                email: r['Email'] ?? r['email'] ?? null,
                contact: r['Contact'] ?? r['contact'] ?? null,
                year: finalYear,
                semester: finalSem,
                attendance: Number(r['Attendance %'] ?? r['attendance'] ?? 0),
                ...monthNums,
                custom_data,
            };

            if (!payload.name) continue;

            // Match student globally (not only current semester)
            const existing = students.find(s =>
                (payload.student_id && String(s.student_id) === String(payload.student_id)) ||
                (payload.name && s.name?.toLowerCase() === payload.name.toLowerCase())
            );

            if (existing) {
                const merged_custom = {
                    ...(existing.custom_data || {}),
                    ...custom_data
                };

                await updateStudent(existing.id, {
                    ...payload,
                    custom_data: merged_custom
                });

                updated++;
            } else {
                await addStudent(payload);
                inserted++;
            }
        }

        await refetch();

        setImporting(false);
        setShowImportPreview(false);

        if (inserted === 0 && updated === 0) {
            showToast('info', 'Already Exists', 'Data already existed.');
        } else {
            showToast(
                'success',
                'Import Successful',
                `${inserted} added, ${updated} updated successfully.`
            );
        }

    } catch (err) {
        console.error(err);
        setImporting(false);
        showToast('error', 'Import Failed', 'Import failed. Please check the file format.');
    }
};
    const inputCls = "w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500";

    return (
        <DashboardLayout>
            {/* Header */}
            <div className="mb-6">
                <h1 className="text-2xl font-bold text-gray-900">Student Management</h1>
                <p className="text-sm text-gray-400 mt-0.5">Manage student records by semester and courses</p>
            </div>

            {/* View tabs */}
            <div className="flex gap-1 mb-5 p-1 bg-gray-100 rounded-lg w-fit">
                {['semesters', 'courses'].map(tab => (
                    <button key={tab} onClick={() => setViewTab(tab)}
                        className={`px-5 py-1.5 rounded-md text-sm font-medium capitalize transition-all ${viewTab === tab ? 'bg-white shadow text-gray-900' : 'text-gray-500 hover:text-gray-700'}`}>
                        {tab.charAt(0).toUpperCase() + tab.slice(1)}
                    </button>
                ))}
            </div>

            {/* Courses Tab */}
            {viewTab === 'courses' && (
                <CoursesView students={students} userId={user?.id} inputCls={inputCls} updateStudent={updateStudent} />
            )}

            {/* Semesters Tab */}
            {viewTab === 'semesters' && (<>
                {/* Add Student button */}
                <div className="mb-4">
                    <button onClick={openAdd}
                        className="flex items-center gap-2 px-4 py-2 bg-[#1a2b4b] text-white rounded-lg text-sm hover:bg-[#243557] font-medium">
                        <Plus className="w-4 h-4" /> Add Student
                    </button>
                </div>

                {/* Year tabs — clicking navigates to first semester of that year */}
                <div className="flex gap-2 mb-3">
                    {YEAR_LABELS.map((label, i) => {
                        const yr = i + 1;
                        const firstSem = YEAR_SEM[yr][0];
                        return (
                            <button key={yr}
                                onClick={() => {
                                    const firstSem = YEAR_SEM[yr][0];
                                    setSelectedYear(yr);
                                    setSelectedSem(firstSem);
                                    setSearchParams({ year: yr, sem: firstSem });
                                }}
                                className={`px-4 py-1.5 rounded-full text-sm font-medium border transition-colors ${selectedYear === yr
                                    ? 'bg-[#1a2b4b] text-white border-[#1a2b4b]'
                                    : 'border-gray-300 text-gray-600 hover:border-gray-400'
                                    }`}>
                                {label}
                            </button>
                        );
                    })}
                </div>

                {/* Semester sub-tabs */}
                <div className="flex gap-2 mb-4">
                    {sems.map(sem => {
                        const cnt = yearStudents.filter(s => Number(s.semester) === sem).length;
                        return (
                            <button key={sem}
                                onClick={() => {
                                    setSelectedSem(sem);
                                    setSearchParams({ year: selectedYear, sem: sem });
                                }}
                                className={`px-4 py-1.5 rounded-full text-sm font-medium border transition-colors ${selectedSem === sem ? 'bg-blue-600 text-white border-blue-600' : 'border-gray-300 text-gray-600 hover:border-gray-400'}`}>
                                Sem {sem} ({cnt})
                            </button>
                        );
                    })}
                </div>

                {/* Table controls */}
                <div className="flex justify-end gap-2 mb-3 relative">

                    {/* Delete Column — multi-select popover */}
                    <div className="relative">
                        <button
                            onClick={() => { setShowDeleteCol(s => !s); setShowAddCol(false); setColsToDelete(new Set()); }}
                            disabled={extraCols.length === 0}
                            title={extraCols.length === 0 ? 'No custom columns to delete' : 'Delete columns'}
                            className="flex items-center gap-2 px-3 py-1.5 border border-red-200 text-red-500 rounded-lg text-sm hover:bg-red-50 disabled:opacity-40 disabled:cursor-not-allowed"
                        >
                            <Trash2 className="w-4 h-4" /> Delete Column
                        </button>

                        {showDeleteCol && extraCols.length > 0 && (
                            <div className="absolute right-0 top-9 bg-white border border-gray-200 rounded-xl shadow-lg p-4 z-20 w-64">
                                <p className="text-xs font-semibold text-gray-700 mb-1">Select columns to remove</p>
                                <p className="text-[10px] text-gray-400 mb-3">Deleted columns are removed from Supabase for this semester.</p>
                                <div className="space-y-1.5 max-h-48 overflow-y-auto mb-3">
                                    {extraCols.map(label => (
                                        <label key={label} className="flex items-center gap-2.5 px-2 py-1.5 rounded-lg hover:bg-gray-50 cursor-pointer">
                                            <input
                                                type="checkbox"
                                                checked={colsToDelete.has(label)}
                                                onChange={() => toggleColToDelete(label)}
                                                className="w-4 h-4 accent-red-500 rounded"
                                            />
                                            <span className="text-sm text-gray-800 truncate">{label}</span>
                                        </label>
                                    ))}
                                </div>
                                <div className="flex gap-2">
                                    <button
                                        onClick={() => { setShowDeleteCol(false); setColsToDelete(new Set()); }}
                                        className="flex-1 py-1.5 border border-gray-200 rounded-lg text-xs text-gray-600 hover:bg-gray-50"
                                    >Cancel</button>
                                    <button
                                        onClick={handleDeleteCols}
                                        disabled={colsToDelete.size === 0}
                                        className="flex-1 py-1.5 bg-red-500 text-white rounded-lg text-xs font-semibold hover:bg-red-600 disabled:opacity-40"
                                    >
                                        Delete ({colsToDelete.size})
                                    </button>
                                </div>
                            </div>
                        )}
                    </div>

                    {/* Add Column */}
                    <div className="relative">
                        <button onClick={() => { setShowAddCol(s => !s); setShowDeleteCol(false); }}
                            className="flex items-center gap-2 px-3 py-1.5 border border-gray-300 rounded-lg text-sm hover:bg-gray-50">
                            <LayoutList className="w-4 h-4" /> Add Column
                        </button>
                        {showAddCol && (
                            <div className="absolute right-0 top-9 bg-white border border-gray-200 rounded-xl shadow-lg p-4 z-10 w-64">
                                <p className="text-xs font-semibold text-gray-600 mb-1">Column Name</p>
                                <p className="text-[10px] text-gray-400 mb-2">Any name — e.g., Internal Marks, Project, April</p>
                                <input
                                    value={newColName}
                                    onChange={e => setNewColName(e.target.value)}
                                    onKeyDown={e => e.key === 'Enter' && handleAddCol()}
                                    placeholder="e.g., April"
                                    className={`${inputCls} mb-2`}
                                    autoFocus
                                />
                                <button onClick={handleAddCol} disabled={!newColName}
                                    className="w-full py-1.5 bg-[#1a2b4b] text-white rounded-lg text-xs font-medium disabled:opacity-40">
                                    Add Column
                                </button>
                            </div>
                        )}
                    </div>

                    {/* Import Excel */}
                    <button onClick={() => fileRef.current?.click()}
                        className="flex items-center gap-2 px-3 py-1.5 border border-gray-300 rounded-lg text-sm hover:bg-gray-50">
                        <Upload className="w-4 h-4" /> Import Excel
                    </button>
                    <input ref={fileRef} type="file" accept=".xlsx,.xls" className="hidden" onChange={handleImport} />
                    {/* Export */}
                    <button onClick={handleExport}
                        className="flex items-center gap-2 px-3 py-1.5 border border-gray-300 rounded-lg text-sm hover:bg-gray-50">
                        <Download className="w-4 h-4" /> Export
                    </button>
                </div>

                {/* Table */}
                {loading ? (
                    <div className="flex justify-center py-20">
                        <div className="w-8 h-8 border-4 border-blue-100 border-t-blue-600 rounded-full animate-spin" />
                    </div>
                ) : (
                    <div className="bg-white rounded-2xl border border-gray-200 overflow-x-auto">
                        <table className="w-full text-sm min-w-[700px]">
                            <thead>
                                <tr className="border-b">
                                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-700">Student ID</th>
                                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-700">Name</th>
                                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-700">Email</th>
                                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-700">Contact</th>
                                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-700">Avg. Attendance</th>
                                    {monthCols.map(c => (
                                        <th key={c.key ?? c.label} className="px-4 py-3 text-left text-xs font-semibold text-gray-700 whitespace-nowrap">{c.label}</th>
                                    ))}
                                    <th className="px-4 py-3 text-right text-xs font-semibold text-gray-700">Actions</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-100">
                                {displayStudents.length === 0 ? (
                                    <tr><td colSpan={7 + monthCols.length} className="py-12 text-center text-gray-400">No students in this group</td></tr>
                                ) : displayStudents.map(s => (
                                    <tr key={s.id} className="hover:bg-gray-50">
                                        <td className="px-4 py-3 text-gray-500">{s.student_id || '—'}</td>
                                        <td className="px-4 py-3 font-medium text-gray-900">{s.name}</td>
                                        <td className="px-4 py-3 text-gray-500 text-xs">{s.email || '—'}</td>
                                        <td className="px-4 py-3 text-gray-500">{s.contact || '—'}</td>
                                        <td className="px-4 py-3"><AttBar value={calcAvgAtt(s)} /></td>
                                        {monthCols.map(c => (
                                            <td key={c.key ?? c.label} className="px-4 py-3">
                                                {c.key
                                                    ? <AttBar value={s[c.key]} />
                                                    : <CustomCell
                                                        student={s}
                                                        colLabel={c.label}
                                                        onSave={async (newVal) => {
                                                            const merged = { ...(s.custom_data || {}), [c.label]: newVal };
                                                            await updateStudent(s.id, { custom_data: merged });
                                                        }}
                                                    />
                                                }
                                            </td>
                                        ))}
                                        <td className="px-4 py-3">
                                            <div className="flex justify-end gap-2">
                                                <button onClick={() => openEdit(s)} className="text-blue-600 hover:text-blue-800 text-xs font-medium">Edit</button>
                                                <button onClick={() => handleDelete(s.id)} className="text-red-500 hover:text-red-700 text-xs font-medium">Delete</button>
                                            </div>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                        <div className="px-4 py-2 border-t text-xs text-gray-400">
                            Showing {displayStudents.length} of {yearStudents.length} students in Year {selectedYear}
                        </div>
                    </div>
                )}
            </>)}

            {showModal && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
                    <div className="bg-white rounded-2xl shadow-xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
                        {/* Modal Header */}
                        <div className="flex items-center justify-between px-6 py-4 border-b sticky top-0 bg-white z-10">
                            <h3 className="font-bold text-gray-900 text-base">{editingId ? 'Edit Student' : 'Add New Student'}</h3>
                            <button onClick={() => setShowModal(false)} className="text-gray-400 hover:text-gray-600"><X className="w-5 h-5" /></button>
                        </div>

                        <div className="p-6 space-y-4">
                            {/* Row: Student ID + Year */}
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="text-xs font-semibold text-gray-600 block mb-1.5">Student ID / Roll No</label>
                                    <input value={form.student_id} onChange={e => setForm(p => ({ ...p, student_id: e.target.value }))}
                                        placeholder="e.g., STU001" className={inputCls} />
                                </div>
                                <div>
                                    <label className="text-xs font-semibold text-gray-600 block mb-1.5">Year</label>
                                    <select value={form.year} onChange={e => setForm(p => ({ ...p, year: e.target.value, semester: String(YEAR_SEM[Number(e.target.value)]?.[0] || 1) }))} className={inputCls}>
                                        {[1, 2, 3, 4].map(y => <option key={y} value={y}>{y === 1 ? '1st' : y === 2 ? '2nd' : y === 3 ? '3rd' : '4th'} Year</option>)}
                                    </select>
                                </div>
                            </div>

                            {/* Semester */}
                            <div>
                                <label className="text-xs font-semibold text-gray-600 block mb-1.5">Semester</label>
                                <select value={form.semester} onChange={e => setForm(p => ({ ...p, semester: e.target.value }))} className={inputCls}>
                                    {(YEAR_SEM[Number(form.year)] || [1, 2]).map(s => <option key={s} value={s}>Sem {s}</option>)}
                                </select>
                            </div>

                            {/* Full Name */}
                            <div>
                                <label className="text-xs font-semibold text-gray-600 block mb-1.5">Full Name</label>
                                <input value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} className={inputCls} placeholder="Enter student full name" />
                            </div>

                            {/* Email + Contact */}
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="text-xs font-semibold text-gray-600 block mb-1.5">Email</label>
                                    <input type="email" value={form.email} onChange={e => setForm(p => ({ ...p, email: e.target.value }))} className={inputCls} placeholder="student@email.com" />
                                </div>
                                <div>
                                    <label className="text-xs font-semibold text-gray-600 block mb-1.5">Contact Number</label>
                                    <input value={form.contact} onChange={e => setForm(p => ({ ...p, contact: e.target.value }))} className={inputCls} placeholder="9890524254" />
                                </div>
                            </div>

                            {/* Monthly Attendance */}
                            <div>
                                <label className="text-xs font-semibold text-gray-600 block mb-2">Monthly Attendance <span className="text-gray-400 font-normal">(Optional)</span></label>
                                <div className="grid grid-cols-3 gap-3">
                                    {[
                                        { key: 'jan_att', label: 'January' }, { key: 'feb_att', label: 'February' }, { key: 'mar_att', label: 'March' },
                                        { key: 'apr_att', label: 'April' }, { key: 'may_att', label: 'May' }, { key: 'jun_att', label: 'June' },
                                        { key: 'jul_att', label: 'July' }, { key: 'aug_att', label: 'August' }, { key: 'sep_att', label: 'September' },
                                        { key: 'oct_att', label: 'October' }, { key: 'nov_att', label: 'November' }, { key: 'dec_att', label: 'December' },
                                    ].map(m => (
                                        <div key={m.key}>
                                            <label className="text-[11px] text-gray-400 block mb-1">{m.label}</label>
                                            <div className="relative">
                                                <input type="number" min={0} max={100}
                                                    value={form[m.key] || ''}
                                                    onChange={e => setForm(p => ({ ...p, [m.key]: e.target.value }))}
                                                    className={`${inputCls} pr-6 text-center`} placeholder="0" />
                                                <span className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 text-xs pointer-events-none">%</span>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>

                        {/* Footer */}
                        <div className="flex gap-3 px-6 pb-6">
                            <button onClick={() => setShowModal(false)}
                                className="flex-1 py-2.5 border border-gray-300 rounded-xl text-sm font-medium text-gray-700 hover:bg-gray-50">
                                Cancel
                            </button>
                            <button onClick={handleSave} disabled={saving || !form.name}
                                className="flex-1 py-2.5 bg-[#1a2b4b] text-white rounded-xl text-sm font-bold disabled:opacity-60 hover:bg-[#243557]">
                                {saving ? 'Saving…' : editingId ? 'Update Student' : 'Add Student'}
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* ── Import Preview Modal ───────────────────────────── */}
{showImportPreview && (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
        <div className="bg-white rounded-2xl shadow-xl w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">

            <div className="flex items-center justify-between px-6 py-4 border-b">
                <h3 className="font-bold text-gray-900">Import Preview</h3>
                <button onClick={() => setShowImportPreview(false)}>
                    <X className="w-5 h-5 text-gray-500" />
                </button>
            </div>

            <div className="overflow-auto p-4 flex-1">
                <table className="w-full text-sm border">
                    <thead>
                        <tr>
                            {Object.keys(previewRows[0] || {}).map(key => (
                                <th key={key} className="border px-2 py-1 bg-gray-100 text-xs">
                                    {key}
                                </th>
                            ))}
                        </tr>
                    </thead>
                    <tbody>
                        {previewRows.map((row, i) => (
                            <tr key={i}>
                                {Object.values(row).map((val, idx) => (
                                    <td key={idx} className="border px-2 py-1 text-xs">
                                        {String(val)}
                                    </td>
                                ))}
                            </tr>
                        ))}
                    </tbody>
                </table>

                {parsedImportData.length > 10 && (
                    <p className="text-xs text-gray-400 mt-2">
                        Showing first 10 rows of {parsedImportData.length}
                    </p>
                )}
            </div>

            <div className="flex gap-3 p-4 border-t">
                <button
                    onClick={() => setShowImportPreview(false)}
                    className="flex-1 py-2 border border-gray-300 rounded-lg text-sm"
                >
                    Cancel
                </button>
                <button
                    onClick={confirmImport}
                    disabled={importing}
                    className="flex-1 py-2 bg-[#1a2b4b] text-white rounded-lg text-sm font-medium disabled:opacity-50"
                >
                    {importing ? 'Importing...' : 'Confirm Import'}
                </button>
            </div>

        </div>
    </div>
)}
{/* ── Toast Notification ───────────────────── */}
{toast && (
    <div className="fixed top-5 right-5 z-[9999]">
        <div
            className={`min-w-[280px] max-w-sm p-4 rounded-xl shadow-xl text-white transition-all
            ${
                toast.type === 'success' ? 'bg-green-600' :
                toast.type === 'error' ? 'bg-red-600' :
                toast.type === 'warning' ? 'bg-yellow-500' :
                'bg-blue-600'
            }`}
        >
            <div className="flex justify-between items-start gap-3">
                <div>
                    <p className="font-semibold text-sm">{toast.title}</p>
                    <p className="text-xs opacity-90 mt-1">{toast.message}</p>
                </div>
                <button
                    onClick={() => setToast(null)}
                    className="text-white/80 hover:text-white"
                >
                    ✕
                </button>
            </div>
        </div>
    </div>
)}

        </DashboardLayout>
    );
}
