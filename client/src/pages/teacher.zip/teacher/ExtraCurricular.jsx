import React, { useState } from 'react';
import { useActivities } from '../../hooks/useActivities.js';
import { Award, Download, Plus, Star, X } from 'lucide-react';
import * as XLSX from 'xlsx';

/* ── Constants ─────────────────────────────────────────────────── */
const MONTH_LABELS = [
    { key: 'jan', label: 'January' }, { key: 'feb', label: 'February' }, { key: 'mar', label: 'March' },
    { key: 'apr', label: 'April' }, { key: 'may', label: 'May' }, { key: 'jun', label: 'June' },
    { key: 'jul', label: 'July' }, { key: 'aug', label: 'August' }, { key: 'sep', label: 'September' },
    { key: 'oct', label: 'October' }, { key: 'nov', label: 'November' }, { key: 'dec', label: 'December' },
];

const ACT_YEAR_SEM = { 1: [1, 2], 2: [3, 4], 3: [5, 6], 4: [7, 8] };
const ACT_YEAR_LABELS = ['1st Year', '2nd Year', '3rd Year', '4th Year'];

/* ── EntryPopup ─────────────────────────────────────────────────── */
function EntryPopup({ month, onSave, onClose }) {
    const [val, setVal] = useState('');
    const [desc, setDesc] = useState('');
    return (
        <div
            className="absolute z-50 top-full left-0 mt-1 bg-white rounded-xl shadow-xl border border-amber-100 p-3 w-52"
            onClick={e => e.stopPropagation()}
        >
            <p className="text-[11px] font-bold text-amber-700 mb-2 flex items-center gap-1">
                <Award className="w-3 h-3" /> Add Credit — {month}
            </p>
            <input
                autoFocus
                type="number" min="0"
                value={val} onChange={e => setVal(e.target.value)}
                placeholder="Points (e.g. 5)"
                onKeyDown={e => { if (e.key === 'Enter') onSave(val, desc); if (e.key === 'Escape') onClose(); }}
                className="w-full px-2 py-1.5 border border-gray-200 rounded-lg text-xs mb-1.5 focus:outline-none focus:ring-2 focus:ring-amber-400"
            />
            <input
                type="text"
                value={desc} onChange={e => setDesc(e.target.value)}
                placeholder="Activity (e.g. Debate)"
                onKeyDown={e => { if (e.key === 'Enter') onSave(val, desc); if (e.key === 'Escape') onClose(); }}
                className="w-full px-2 py-1.5 border border-gray-200 rounded-lg text-xs mb-2 focus:outline-none focus:ring-2 focus:ring-amber-400"
            />
            <div className="flex gap-1.5">
                <button onClick={onClose} className="flex-1 py-1 border border-gray-200 rounded-lg text-[11px] text-gray-500 hover:bg-gray-50">Cancel</button>
                <button onClick={() => onSave(val, desc)} className="flex-1 py-1 bg-amber-500 hover:bg-amber-600 text-white rounded-lg text-[11px] font-semibold">Add</button>
            </div>
        </div>
    );
}

/* ── ExtraCurricular (main export) ─────────────────────────────── */
export default function ExtraCurricular({ students, userId }) {
    const { addEntry, deleteEntry, getEntries, getTotal, getMonthTotal } = useActivities(userId);

    // Filters
    const [actYear, setActYear] = useState(1);
    const [actSem, setActSem] = useState(1);
    const [actSearch, setActSearch] = useState('');

    // Selected student (null = show student grid)
    const [selectedStudent, setSelectedStudent] = useState(null);

    // Which cell has its "add" popup open: "month" or null
    const [openCell, setOpenCell] = useState(null);

    const sems = ACT_YEAR_SEM[actYear] || [1, 2];

    const filtered = students.filter(s => {
        const matchSem = Number(s.year) === actYear && Number(s.semester) === actSem;
        const q = actSearch.toLowerCase();
        const matchSearch = !q || s.name?.toLowerCase().includes(q) || s.student_id?.toLowerCase().includes(q);
        return matchSem && matchSearch;
    });

    // Keep selectedStudent in sync if students list changes
    const activeStudent = selectedStudent
        ? students.find(s => s.id === selectedStudent.id) || selectedStudent
        : null;

    const handleSave = (monthKey, val, desc) => {
        if (val && activeStudent) addEntry(activeStudent.id, monthKey, val, desc);
        setOpenCell(null);
    };

    const handleExport = () => {
        const rows = [];
        const exportList = activeStudent ? [activeStudent] : filtered;
        MONTH_LABELS.forEach(m => {
            exportList.forEach(s => {
                const entries = getEntries(s.id, m.key);
                if (entries.length === 0) return;
                entries.forEach(e => {
                    rows.push({
                        Month: m.label,
                        'Student ID': s.student_id || '',
                        Name: s.name || '',
                        'Credit Points': e.value,
                        'Activity / Description': e.desc || '',
                    });
                });
            });
        });
        if (rows.length === 0) { alert('No data to export.'); return; }
        const ws = XLSX.utils.json_to_sheet(rows);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, 'Activities');
        XLSX.writeFile(wb, 'extra_curricular_activities.xlsx');
    };

    return (
        <div onClick={() => setOpenCell(null)}>

            {/* ── Header ── */}
            <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
                <div className="flex items-center gap-2 text-base font-bold text-gray-900">
                    {activeStudent ? (
                        <button
                            onClick={() => { setSelectedStudent(null); setOpenCell(null); }}
                            className="flex items-center gap-1.5 text-sm font-medium text-gray-500 hover:text-gray-800 mr-1"
                        >
                            <X className="w-4 h-4" /> Back
                        </button>
                    ) : null}
                    <Award className="w-5 h-5 text-amber-500" />
                    {activeStudent
                        ? <><span>{activeStudent.name}</span><span className="text-xs font-normal text-gray-400 ml-1">— Extra Curricular Credits</span></>
                        : <>Extra Curricular Activities<span className="text-xs font-normal text-gray-400 ml-1">Click a student to add credits</span></>
                    }
                </div>
                <div className="flex items-center gap-2">
                    {!activeStudent && (
                        <input
                            value={actSearch} onChange={e => setActSearch(e.target.value)}
                            placeholder="Search student…"
                            className="pl-3 pr-3 py-1.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-amber-400 w-40"
                        />
                    )}
                    <button onClick={handleExport}
                        className="flex items-center gap-2 px-3 py-1.5 border border-gray-300 rounded-lg text-sm hover:bg-gray-50">
                        <Download className="w-4 h-4" /> Export
                    </button>
                </div>
            </div>

            {/* ── Year & Semester pills (only when no student selected) ── */}
            {!activeStudent && (
                <>
                    <div className="flex gap-2 mb-3 flex-wrap">
                        {ACT_YEAR_LABELS.map((label, i) => {
                            const yr = i + 1;
                            return (
                                <button key={yr}
                                    onClick={() => { setActYear(yr); setActSem(ACT_YEAR_SEM[yr][0]); }}
                                    className={`px-4 py-1.5 rounded-full text-sm font-medium border transition-colors ${actYear === yr
                                        ? 'bg-[#1a2b4b] text-white border-[#1a2b4b]'
                                        : 'border-gray-300 text-gray-600 hover:border-gray-400'}`}
                                >{label}</button>
                            );
                        })}
                    </div>
                    <div className="flex gap-2 mb-5">
                        {sems.map(sem => {
                            const cnt = students.filter(s => Number(s.year) === actYear && Number(s.semester) === sem).length;
                            return (
                                <button key={sem} onClick={() => setActSem(sem)}
                                    className={`px-4 py-1.5 rounded-full text-sm font-medium border transition-colors ${actSem === sem
                                        ? 'bg-amber-500 text-white border-amber-500'
                                        : 'border-gray-300 text-gray-600 hover:border-amber-300'}`}
                                >Sem {sem} ({cnt})</button>
                            );
                        })}
                    </div>
                </>
            )}

            {/* ── STUDENT CARD GRID (no student selected) ── */}
            {!activeStudent && (
                filtered.length === 0 ? (
                    <div className="bg-white rounded-2xl border border-gray-200 py-16 text-center text-gray-400">
                        <Star className="w-12 h-12 mx-auto mb-3 opacity-20" />
                        <p className="font-medium">No students in Year {actYear} · Sem {actSem}</p>
                        <p className="text-xs mt-1">Add students from the Semesters tab first.</p>
                    </div>
                ) : (
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                        {filtered.map(s => {
                            const tot = getTotal(s.id);
                            return (
                                <button
                                    key={s.id}
                                    onClick={() => setSelectedStudent(s)}
                                    className="bg-white border border-gray-200 rounded-2xl p-4 flex flex-col items-center gap-2 hover:border-amber-400 hover:shadow-md transition-all group"
                                >
                                    <div className="w-12 h-12 rounded-full bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center text-white text-lg font-bold group-hover:scale-105 transition-transform">
                                        {s.name?.[0]?.toUpperCase() || '?'}
                                    </div>
                                    <p className="text-sm font-semibold text-gray-800 text-center leading-tight">{s.name}</p>
                                    <p className="text-[11px] text-gray-400 font-mono">{s.student_id || '—'}</p>
                                    {tot > 0 ? (
                                        <span className="px-2 py-0.5 bg-amber-100 text-amber-700 rounded-full text-[11px] font-bold">{tot} pts</span>
                                    ) : (
                                        <span className="px-2 py-0.5 bg-gray-100 text-gray-400 rounded-full text-[11px]">No credits</span>
                                    )}
                                </button>
                            );
                        })}
                    </div>
                )
            )}

            {/* ── SINGLE STUDENT CREDIT TABLE ── */}
            {activeStudent && (
                <div onClick={e => e.stopPropagation()}>
                    {/* Student info bar */}
                    <div className="flex items-center gap-3 mb-4 bg-amber-50 border border-amber-100 rounded-xl px-4 py-3">
                        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center text-white font-bold text-base">
                            {activeStudent.name?.[0]?.toUpperCase() || '?'}
                        </div>
                        <div>
                            <p className="font-semibold text-gray-800">{activeStudent.name}</p>
                            <p className="text-xs text-gray-400">ID: {activeStudent.student_id || '—'} · Year {activeStudent.year} · Sem {activeStudent.semester}</p>
                        </div>
                        <div className="ml-auto">
                            <span className="px-3 py-1 bg-amber-500 text-white rounded-full text-xs font-bold">
                                Total: {getTotal(activeStudent.id)} pts
                            </span>
                        </div>
                    </div>

                    {/* Monthly credit table */}
                    <div className="bg-white rounded-2xl border border-gray-200 overflow-hidden">
                        <table className="w-full text-sm">
                            <thead className="bg-gray-50 border-b border-gray-200">
                                <tr>
                                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase w-32">Month</th>
                                    <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Credits &amp; Activities</th>
                                    <th className="px-4 py-3 text-center text-xs font-semibold text-amber-600 uppercase w-24">Total</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-100">
                                {MONTH_LABELS.map(m => {
                                    const entries = getEntries(activeStudent.id, m.key);
                                    const monthTot = getMonthTotal(activeStudent.id, m.key);
                                    return (
                                        <tr key={m.key} className="hover:bg-amber-50/30 transition-colors align-top">
                                            <td className="px-4 py-3">
                                                <span className="text-xs font-bold text-gray-700">{m.label}</span>
                                            </td>
                                            <td className="px-4 py-2">
                                                <div className="flex flex-wrap gap-1.5 items-center">
                                                    {entries.map(entry => (
                                                        <div key={entry.id}
                                                            className="flex items-center gap-1 bg-amber-50 border border-amber-100 rounded-lg px-2 py-1 group"
                                                        >
                                                            <span className="shrink-0 bg-amber-500 text-white text-[11px] font-bold rounded-full w-5 h-5 flex items-center justify-center">
                                                                {entry.value}
                                                            </span>
                                                            {entry.desc && (
                                                                <p className="text-[11px] text-amber-900">{entry.desc}</p>
                                                            )}
                                                            <button
                                                                onClick={() => deleteEntry(activeStudent.id, m.key, entry.id)}
                                                                className="opacity-0 group-hover:opacity-100 text-red-400 hover:text-red-600 transition-opacity ml-0.5"
                                                                title="Remove"
                                                            >
                                                                <X className="w-3 h-3" />
                                                            </button>
                                                        </div>
                                                    ))}
                                                    {/* Add button */}
                                                    <div className="relative" onClick={e => e.stopPropagation()}>
                                                        <button
                                                            onClick={() => setOpenCell(prev => prev === m.key ? null : m.key)}
                                                            className="flex items-center gap-0.5 px-2 py-1 rounded-lg border border-dashed border-gray-300 text-gray-400 hover:border-amber-400 hover:text-amber-500 hover:bg-amber-50 transition-colors text-xs"
                                                        >
                                                            <Plus className="w-3 h-3" /> Add
                                                        </button>
                                                        {openCell === m.key && (
                                                            <EntryPopup
                                                                month={m.label}
                                                                onSave={(v, d) => handleSave(m.key, v, d)}
                                                                onClose={() => setOpenCell(null)}
                                                            />
                                                        )}
                                                    </div>
                                                </div>
                                            </td>
                                            <td className="px-4 py-3 text-center">
                                                {monthTot > 0 ? (
                                                    <span className="inline-flex items-center justify-center h-6 px-2 rounded-lg text-xs font-bold bg-amber-500 text-white">
                                                        {monthTot}
                                                    </span>
                                                ) : (
                                                    <span className="text-gray-300 text-xs">—</span>
                                                )}
                                            </td>
                                        </tr>
                                    );
                                })}
                            </tbody>
                            <tfoot className="bg-amber-50 border-t-2 border-amber-200">
                                <tr>
                                    <td className="px-4 py-3 text-xs font-bold text-amber-700">Grand Total</td>
                                    <td></td>
                                    <td className="px-4 py-3 text-center">
                                        <span className="inline-flex items-center justify-center h-7 px-3 rounded-lg text-xs font-bold bg-[#1a2b4b] text-white">
                                            {getTotal(activeStudent.id)}
                                        </span>
                                    </td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            )}
        </div>
    );
}
